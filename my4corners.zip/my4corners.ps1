﻿



Function notatallGraphall 
{

  param (
        [string]$text,
        [string]$global:disk
    )





if (!($data))
{ $data = Import-Csv -Path "$mydir\dat.csv" -ErrorAction SilentlyContinue -WarningAction SilentlyContinue; Sleep(3)}



 
 

# Filter the data to include only rows where the Operation column contains "Read"
$read_data = $data | Where-Object { $_.Operation -like "*Read*" }
sleep (3)

 


# Split the data into two sets based on the Access column
$read_random_access_data = $read_data | Where-Object { $_.Access -like "*Random*" }
$read_sequential_access_data = $read_data | Where-Object { $_.Access -like "*Sequential*" }

#########test random read and sequential read data 
$read_random_access_data | ft
$read_sequential_access_data | ft

# Combine the two sets of data and create a new property to identify the access type
$read_combined_ran = $read_random_access_data | Select-Object @{Name="Access";Expression={"Random"}},Blocks,IOPS
$Read_combined_seq = $read_sequential_access_data | Select-Object @{Name="Access";Expression={"Sequential"}},Blocks,MB/sec

##### FILTER THE DATA FOR WRITE DATA 
# Filter the data to include only rows where the Operation column contains "Write"
 $write_data = $data | Where-Object { $_.Operation -like "*Write*" }

# Split the data into two sets based on the Access column
$random_write_access_data = $write_data | Where-Object { $_.Access -like "Random" }
$sequential_write_access_data = $write_data | Where-Object { $_.Access -like "Sequential" }

# Combine the two sets of data and create a new property to identify the access type
$write_combined_ran = $random_write_access_data | Select-Object @{Name="Access";Expression={"Random"}},Blocks,IOPS
$Write_combined_seq = $sequential_write_access_data | Select-Object @{Name="Access";Expression={"Sequential"}},Blocks,MB/sec

#### test random and sequentual writes 
#$write_combined_ran | ft
#$Write_combined_seq | ft
$random_write_access_data | ft
$sequential_write_access_data | ft


#### FINISH FILTER FOR WRITE DATA 
# Calculate the maximum Y-value for all data points
# Find the largest value for IOPS in each dataset
$maxIOPS_read_ran = $read_combined_ran.IOPS | Measure-Object -Maximum | Select-Object -ExpandProperty Maximum
$maxIOPS_read_seq = $Read_combined_seq.IOPS | Measure-Object -Maximum | Select-Object -ExpandProperty Maximum
$maxIOPS_write_ran = $write_combined_ran.IOPS | Measure-Object -Maximum | Select-Object -ExpandProperty Maximum
$maxIOPS_write_seq = $Write_combined_seq.IOPS | Measure-Object -Maximum | Select-Object -ExpandProperty Maximum

# Find the largest value for MB/sec in each dataset
$maxMBSec_read_seq = $Read_combined_seq."MB/sec" | Measure-Object -Maximum | Select-Object -ExpandProperty Maximum
$maxMBSec_write_seq = $Write_combined_seq."MB/sec" | Measure-Object -Maximum | Select-Object -ExpandProperty Maximum

# the format has to be just like below
# Test N#	 Drive	 Operation	 Access	 Blocks	 Run N#	 IOPS	 MB/sec	 Latency ms	 CPU %
# place the numbers in the csv as csv or space seperated values 

# set path asap 
$mypath = $MyInvocation.MyCommand.path
$mydir = split-path $mypath -Parent

Set-Location -Path $mydir

$mydownloads = (New-Object -ComObject Shell.Application).NameSpace('shell:Downloads').Self.Path
$myscriptloc = $PSScriptRoot
Set-Location  "$mydownloads\CornersTestandGraph2.0\"
$mydir = $pwd
Clear-Host

#Write-host "The CSV file needs to be in this folder. It also must be in the proper format like the dat.csv"
#write-host "Failure to do those things will result in you getting nothing valuable from this forray" -BackgroundColor Green
#$keypressed = "dat.csv"
#$keybus = Read-host "enter the name of the file you want me to do your work for you on. Enter=dat.csv"

#if ([bool] $keybus -eq $true) {$keypressed = $keybus} else {$keypressed = "dat.csv"}
 
  

# Filter the data to include only rows where the Operation column contains "Read"
$read_data = $data | Where-Object { $_.Operation -like "*Read*" }


# Split the data into two sets based on the Access column
$read_random_access_data = $read_data | Where-Object { $_.Access -like "*Random*" }
$read_sequential_access_data = $read_data | Where-Object { $_.Access -like "*Sequential*" }

#########test random read and sequential read data 
$read_random_access_data | ft
$read_sequential_access_data | ft

# Combine the two sets of data and create a new property to identify the access type
$read_combined_ran = $read_random_access_data | Select-Object @{Name="Access";Expression={"Random"}},Blocks,IOPS
$Read_combined_seq = $read_sequential_access_data | Select-Object @{Name="Access";Expression={"Sequential"}},Blocks,MB/sec

##### FILTER THE DATA FOR WRITE DATA 
# Filter the data to include only rows where the Operation column contains "Write"
 $write_data = $data | Where-Object { $_.Operation -like "*Write*" }

# Split the data into two sets based on the Access column
$random_write_access_data = $write_data | Where-Object { $_.Access -like "Random" }
$sequential_write_access_data = $write_data | Where-Object { $_.Access -like "Sequential" }

# Combine the two sets of data and create a new property to identify the access type
$write_combined_ran = $random_write_access_data | Select-Object @{Name="Access";Expression={"Random"}},Blocks,IOPS
$Write_combined_seq = $sequential_write_access_data | Select-Object @{Name="Access";Expression={"Sequential"}},Blocks,MB/sec

#### test random and sequentual writes 
#$write_combined_ran | ft
#$Write_combined_seq | ft
$random_write_access_data | ft
$sequential_write_access_data | ft


#### FINISH FILTER FOR WRITE DATA 
# Calculate the maximum Y-value for all data points
# Find the largest value for IOPS in each dataset
$maxIOPS_read_ran = $read_combined_ran.IOPS | Measure-Object -Maximum | Select-Object -ExpandProperty Maximum
$maxIOPS_read_seq = $Read_combined_seq.IOPS | Measure-Object -Maximum | Select-Object -ExpandProperty Maximum
$maxIOPS_write_ran = $write_combined_ran.IOPS | Measure-Object -Maximum | Select-Object -ExpandProperty Maximum
$maxIOPS_write_seq = $Write_combined_seq.IOPS | Measure-Object -Maximum | Select-Object -ExpandProperty Maximum

# Find the largest value for MB/sec in each dataset
$maxMBSec_read_seq = $Read_combined_seq."MB/sec" | Measure-Object -Maximum | Select-Object -ExpandProperty Maximum
$maxMBSec_write_seq = $Write_combined_seq."MB/sec" | Measure-Object -Maximum | Select-Object -ExpandProperty Maximum
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

$global:form = New-Object System.Windows.Forms.Form

# Calculate the maximum Y-value by finding the largest value among all datasets
$maxYValue = ($maxIOPS_read_ran, $maxIOPS_read_seq, $maxIOPS_write_ran, $maxIOPS_write_seq) | Measure-Object -Maximum | Select-Object -ExpandProperty Maximum
$maxY2Value = ($maxMBSec_read_seq, $maxMBSec_write_seq) | Measure-Object -Maximum | Select-Object -ExpandProperty Maximum

# Create the graph
$chart = New-Object System.Windows.Forms.DataVisualization.Charting.Chart
$chart.Width = 800
$chart.Height = 600

$chartArea = New-Object System.Windows.Forms.DataVisualization.Charting.ChartArea
$chart.ChartAreas.Add($chartArea)

$legend = New-Object System.Windows.Forms.DataVisualization.Charting.Legend
$legend.Docking = "bottom"
$chart.Legends.Add($legend)

$dataSeries1 = New-Object System.Windows.Forms.DataVisualization.Charting.Series
$dataSeries1.Name = "Random Read"
$dataSeries1.XValueType = [System.Windows.Forms.DataVisualization.Charting.ChartValueType]::String
$dataSeries1.YValueType = [System.Windows.Forms.DataVisualization.Charting.ChartValueType]::Double
$dataSeries1.ChartType = [System.Windows.Forms.DataVisualization.Charting.SeriesChartType]::Line
$dataSeries1.BorderWidth = 2
$dataSeries1.Color = [System.Drawing.Color]::Blue

$dataSeries2 = New-Object System.Windows.Forms.DataVisualization.Charting.Series
$dataSeries2.Name = "Sequential Read"
$dataSeries2.XValueType = [System.Windows.Forms.DataVisualization.Charting.ChartValueType]::String
$dataSeries2.YValueType = [System.Windows.Forms.DataVisualization.Charting.ChartValueType]::Double
$dataSeries2.ChartType = [System.Windows.Forms.DataVisualization.Charting.SeriesChartType]::Line
$dataSeries2.BorderWidth = 2
$dataSeries2.Color = [System.Drawing.Color]::Yellow
$dataSeries2.YAxisType = [System.Windows.Forms.DataVisualization.Charting.AxisType]::Secondary  # Set YAxisType to Secondary

$dataSeries11 = New-Object System.Windows.Forms.DataVisualization.Charting.Series
$dataSeries11.Name = "Random Write"
$dataSeries11.XValueType = [System.Windows.Forms.DataVisualization.Charting.ChartValueType]::String
$dataSeries11.YValueType = [System.Windows.Forms.DataVisualization.Charting.ChartValueType]::Double
$dataSeries11.ChartType = [System.Windows.Forms.DataVisualization.Charting.SeriesChartType]::Line
$dataSeries11.BorderWidth = 2
$dataSeries11.Color = [System.Drawing.Color]::Green

$dataSeries21 = New-Object System.Windows.Forms.DataVisualization.Charting.Series
$dataSeries21.Name = "Sequential Write"
$dataSeries21.XValueType = [System.Windows.Forms.DataVisualization.Charting.ChartValueType]::String
$dataSeries21.YValueType = [System.Windows.Forms.DataVisualization.Charting.ChartValueType]::Double
$dataSeries21.ChartType = [System.Windows.Forms.DataVisualization.Charting.SeriesChartType]::Line
$dataSeries21.BorderWidth = 2
$dataSeries21.Color = [System.Drawing.Color]::Magenta
$dataSeries21.YAxisType = [System.Windows.Forms.DataVisualization.Charting.AxisType]::Secondary  # Set YAxisType to Secondary

# Create the first Y-axis
$yAxis1 = $chart.ChartAreas[0].AxisY
$yAxis1.Title = "IOPS"
$yAxis1.MajorGrid.Enabled = $false
$yAxis1.LabelStyle.Format = "0"
$yAxis1.Maximum = $maxYValue

# Create the second Y-axis
$yAxis2 = $chart.ChartAreas[0].AxisY2
$yAxis2.Title = "MB/sec"
$yAxis2.MajorGrid.Enabled = $false
$yAxis2.LabelStyle.Format = "0"
$yAxis2.Maximum = $maxY2Value

$ChartTitle = New-Object System.Windows.Forms.DataVisualization.Charting.Title
$ChartTitle.Text = 'Sequential =Mb/Sec (yellow,Magenta) / IO = IOPS count (Green,BLue)'
$Font = New-Object System.Drawing.Font @('Microsoft Sans Serif','9', [System.Drawing.FontStyle]::Bold)
$ChartTitle.Font =$Font
$Chart.Titles.Add($ChartTitle)


foreach ($item in $read_combined_ran) {
    $blocks= $item."blocks"
    $access = $item.Access
    #$mb_sec = $item."MB/sec"
    $iops = $item.IOPS
    
    if ($access -eq "Random") {
        $dataSeries1.Points.AddXY($Blocks,$iops)
    } 
}
 
foreach ($item in $Read_combined_seq) {
    $access = $item.Access
    $mb_sec = $item."MB/sec"
    $blocks = $item."Blocks"
   # $iops = $item.IOPS

    if ($access -like "Sequential") {
        $dataSeries2.Points.AddXY($blocks, $mb_sec)
    }
        
   
}

foreach ($item in $write_combined_ran) {
    $access = $item.Access
    $iops = $item.IOPS
    $blocks = $item."Blocks"

    if ($access -eq "Random") {
        $dataSeries11.Points.AddXY($Blocks, $iops)
    }
}

foreach ($item in $Write_combined_seq) {
    $access = $item.Access
    $mb_sec = $item."MB/sec"
    $blocks = $item."Blocks"
    if ($access -eq "Sequential") {
        Write-Host "Adding sequential write data point: Blocks=$blocks, MB/sec=$mb_sec"
        $dataSeries21.Points.AddXY($Blocks, $mb_sec)
    }
}


$chart.Series.Add($dataSeries1)
$chart.Series.Add($dataSeries2)

$chart.Series.Add($dataSeries11)
$chart.Series.Add($dataSeries21)

 

$chart.SaveImage("$mydir\Graphall.png", [System.Drawing.Imaging.ImageFormat]::Png)
#$combined_data | ConvertTo-Json | Out-File "$mydir\data.json" -Append
$read_combined_ran | ConvertTo-Json | Out-File "$mydir\Graphall.json" -Append
$Read_combined_seq | ConvertTo-Json | Out-File "$mydir\Graphall.json" -Append
$write_combined_ran | ConvertTo-Json | Out-File "$mydir\Graphall.json" -Append
$Write_combined_seq | ConvertTo-Json | Out-File "$mydir\Graphall.json" -Append


## Rule For Sequential IO - THROUGHPUT Don’t worry about the IO- Only the throughput matters
### Rule	For Random IO- Only IOPS matters- don’t worry about throughput 



$chartForm = New-Object System.Windows.Forms.Form
$chartForm.SuspendLayout()
$chart.Dock = [System.Windows.Forms.DockStyle]::Fill
$chartForm.Controls.Add($chart)
$chartForm.ResumeLayout()



 


# Show the form
 

# ... (rest of the Graphall function)

# Show the form
$chartForm.ShowDialog()

# Set the PictureBox's Image property to the newly generated chart image
$pictureBoxImage.Image = [System.Drawing.Image]::FromFile("$mydir\Graphall.png")

 



}

Function Graphall 
{

  param (
        [string]$text,
        [string]$global:disk
    )


$data= $null

# the format has to be just like below
# Test N#	 Drive	 Operation	 Access	 Blocks	 Run N#	 IOPS	 MB/sec	 Latency ms	 CPU %
# place the numbers in the csv as csv or space seperated values 
Add-Type -AssemblyName System.Windows.Forms
 Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Windows.Forms.DataVisualization

$mydownloads = (New-Object -ComObject Shell.Application).NameSpace('shell:Downloads').Self.Path
$myscriptloc = $PSScriptRoot
$mydir = "$mydownloads\CornersTestandGraph2.0\"
Set-Location -path  "$mydownloads\CornersTestandGraph2.0\"

# Get all PNG files in the directory (excluding "example.png")
$pngFiles = Get-ChildItem -Path $mydir -Filter "*.png" | Where-Object { $_.Name -ne "example.png" }

# Do something with the selected PNG files (e.g., process them or display their names)
If (!($pngFiles)) { 
$timecost.text = "Intake new Job..."

if (test-path -Path dat.old ) {del dat.old -force}
 
 if (test-path -Path output.txt) {
  
    if (test-path -Path $mydir\dat.csv) { Rename-Item -Path dat.csv -NewName dat.old -force; sleep(2) }
    Rename-Item -Path output.txt -NewName dat.csv -force ; sleep (3)
  }

  # Load the data from a CSV file
$data = Import-Csv -Path "$mydir\dat.csv"

Sleep(3)

  }


if (!($data))
{ $data = Import-Csv -Path "$mydir\dat.csv" -ErrorAction SilentlyContinue -WarningAction SilentlyContinue; Sleep(3)}



 
 

# Filter the data to include only rows where the Operation column contains "Read"
$read_data = $data | Where-Object { $_.Operation -like "*Read*" }
sleep (3)

 


# Split the data into two sets based on the Access column
$read_random_access_data = $read_data | Where-Object { $_.Access -like "*Random*" }
$read_sequential_access_data = $read_data | Where-Object { $_.Access -like "*Sequential*" }

#########test random read and sequential read data 
$read_random_access_data | ft
$read_sequential_access_data | ft

# Combine the two sets of data and create a new property to identify the access type
$read_combined_ran = $read_random_access_data | Select-Object @{Name="Access";Expression={"Random"}},Blocks,IOPS
$Read_combined_seq = $read_sequential_access_data | Select-Object @{Name="Access";Expression={"Sequential"}},Blocks,MB/sec

##### FILTER THE DATA FOR WRITE DATA 
# Filter the data to include only rows where the Operation column contains "Write"
 $write_data = $data | Where-Object { $_.Operation -like "*Write*" }

# Split the data into two sets based on the Access column
$random_write_access_data = $write_data | Where-Object { $_.Access -like "Random" }
$sequential_write_access_data = $write_data | Where-Object { $_.Access -like "Sequential" }

# Combine the two sets of data and create a new property to identify the access type
$write_combined_ran = $random_write_access_data | Select-Object @{Name="Access";Expression={"Random"}},Blocks,IOPS
$Write_combined_seq = $sequential_write_access_data | Select-Object @{Name="Access";Expression={"Sequential"}},Blocks,MB/sec

#### test random and sequentual writes 
#$write_combined_ran | ft
#$Write_combined_seq | ft
$random_write_access_data | ft
$sequential_write_access_data | ft


#### FINISH FILTER FOR WRITE DATA 
# Calculate the maximum Y-value for all data points
# Find the largest value for IOPS in each dataset
$maxIOPS_read_ran = $read_combined_ran.IOPS | Measure-Object -Maximum | Select-Object -ExpandProperty Maximum
$maxIOPS_read_seq = $Read_combined_seq.IOPS | Measure-Object -Maximum | Select-Object -ExpandProperty Maximum
$maxIOPS_write_ran = $write_combined_ran.IOPS | Measure-Object -Maximum | Select-Object -ExpandProperty Maximum
$maxIOPS_write_seq = $Write_combined_seq.IOPS | Measure-Object -Maximum | Select-Object -ExpandProperty Maximum

# Find the largest value for MB/sec in each dataset
$maxMBSec_read_seq = $Read_combined_seq."MB/sec" | Measure-Object -Maximum | Select-Object -ExpandProperty Maximum
$maxMBSec_write_seq = $Write_combined_seq."MB/sec" | Measure-Object -Maximum | Select-Object -ExpandProperty Maximum

# the format has to be just like below
# Test N#	 Drive	 Operation	 Access	 Blocks	 Run N#	 IOPS	 MB/sec	 Latency ms	 CPU %
# place the numbers in the csv as csv or space seperated values 

# set path asap 
$mypath = $MyInvocation.MyCommand.path
$mydir = split-path $mypath -Parent

Set-Location -Path $mydir

$mydownloads = (New-Object -ComObject Shell.Application).NameSpace('shell:Downloads').Self.Path
$myscriptloc = $PSScriptRoot
Set-Location  "$mydownloads\CornersTestandGraph2.0\"
$mydir = $pwd
Clear-Host
#Write-host "The CSV file needs to be in this folder. It also must be in the proper format like the dat.csv"
#write-host "Failure to do those things will result in you getting nothing valuable from this forray" -BackgroundColor Green
#$keypressed = "dat.csv"
#$keybus = Read-host "enter the name of the file you want me to do your work for you on. Enter=dat.csv"

#if ([bool] $keybus -eq $true) {$keypressed = $keybus} else {$keypressed = "dat.csv"}
 
  

# Filter the data to include only rows where the Operation column contains "Read"
$read_data = $data | Where-Object { $_.Operation -like "*Read*" }


# Split the data into two sets based on the Access column
$read_random_access_data = $read_data | Where-Object { $_.Access -like "*Random*" }
$read_sequential_access_data = $read_data | Where-Object { $_.Access -like "*Sequential*" }

#########test random read and sequential read data 
$read_random_access_data | ft
$read_sequential_access_data | ft

# Combine the two sets of data and create a new property to identify the access type
$read_combined_ran = $read_random_access_data | Select-Object @{Name="Access";Expression={"Random"}},Blocks,IOPS
$Read_combined_seq = $read_sequential_access_data | Select-Object @{Name="Access";Expression={"Sequential"}},Blocks,MB/sec

##### FILTER THE DATA FOR WRITE DATA 
# Filter the data to include only rows where the Operation column contains "Write"
 $write_data = $data | Where-Object { $_.Operation -like "*Write*" }

# Split the data into two sets based on the Access column
$random_write_access_data = $write_data | Where-Object { $_.Access -like "Random" }
$sequential_write_access_data = $write_data | Where-Object { $_.Access -like "Sequential" }

# Combine the two sets of data and create a new property to identify the access type
$write_combined_ran = $random_write_access_data | Select-Object @{Name="Access";Expression={"Random"}},Blocks,IOPS
$Write_combined_seq = $sequential_write_access_data | Select-Object @{Name="Access";Expression={"Sequential"}},Blocks,MB/sec

#### test random and sequentual writes 
#$write_combined_ran | ft
#$Write_combined_seq | ft
$random_write_access_data | ft
$sequential_write_access_data | ft


#### FINISH FILTER FOR WRITE DATA 
# Calculate the maximum Y-value for all data points
# Find the largest value for IOPS in each dataset
$maxIOPS_read_ran = $read_combined_ran.IOPS | Measure-Object -Maximum | Select-Object -ExpandProperty Maximum
$maxIOPS_read_seq = $Read_combined_seq.IOPS | Measure-Object -Maximum | Select-Object -ExpandProperty Maximum
$maxIOPS_write_ran = $write_combined_ran.IOPS | Measure-Object -Maximum | Select-Object -ExpandProperty Maximum
$maxIOPS_write_seq = $Write_combined_seq.IOPS | Measure-Object -Maximum | Select-Object -ExpandProperty Maximum

# Find the largest value for MB/sec in each dataset
$maxMBSec_read_seq = $Read_combined_seq."MB/sec" | Measure-Object -Maximum | Select-Object -ExpandProperty Maximum
$maxMBSec_write_seq = $Write_combined_seq."MB/sec" | Measure-Object -Maximum | Select-Object -ExpandProperty Maximum
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

$global:form = New-Object System.Windows.Forms.Form

# Calculate the maximum Y-value by finding the largest value among all datasets
$maxYValue = ($maxIOPS_read_ran, $maxIOPS_read_seq, $maxIOPS_write_ran, $maxIOPS_write_seq) | Measure-Object -Maximum | Select-Object -ExpandProperty Maximum
$maxY2Value = ($maxMBSec_read_seq, $maxMBSec_write_seq) | Measure-Object -Maximum | Select-Object -ExpandProperty Maximum

# Create the graph
$chart = New-Object System.Windows.Forms.DataVisualization.Charting.Chart
$chart.Width = 800
$chart.Height = 600

$chartArea = New-Object System.Windows.Forms.DataVisualization.Charting.ChartArea
$chart.ChartAreas.Add($chartArea)

$legend = New-Object System.Windows.Forms.DataVisualization.Charting.Legend
$legend.Docking = "bottom"
$chart.Legends.Add($legend)

$dataSeries1 = New-Object System.Windows.Forms.DataVisualization.Charting.Series
$dataSeries1.Name = "Random Read"
$dataSeries1.XValueType = [System.Windows.Forms.DataVisualization.Charting.ChartValueType]::String
$dataSeries1.YValueType = [System.Windows.Forms.DataVisualization.Charting.ChartValueType]::Double
$dataSeries1.ChartType = [System.Windows.Forms.DataVisualization.Charting.SeriesChartType]::Line
$dataSeries1.BorderWidth = 2
$dataSeries1.Color = [System.Drawing.Color]::Blue

$dataSeries2 = New-Object System.Windows.Forms.DataVisualization.Charting.Series
$dataSeries2.Name = "Sequential Read"
$dataSeries2.XValueType = [System.Windows.Forms.DataVisualization.Charting.ChartValueType]::String
$dataSeries2.YValueType = [System.Windows.Forms.DataVisualization.Charting.ChartValueType]::Double
$dataSeries2.ChartType = [System.Windows.Forms.DataVisualization.Charting.SeriesChartType]::Line
$dataSeries2.BorderWidth = 2
$dataSeries2.Color = [System.Drawing.Color]::Yellow
$dataSeries2.YAxisType = [System.Windows.Forms.DataVisualization.Charting.AxisType]::Secondary  # Set YAxisType to Secondary

$dataSeries11 = New-Object System.Windows.Forms.DataVisualization.Charting.Series
$dataSeries11.Name = "Random Write"
$dataSeries11.XValueType = [System.Windows.Forms.DataVisualization.Charting.ChartValueType]::String
$dataSeries11.YValueType = [System.Windows.Forms.DataVisualization.Charting.ChartValueType]::Double
$dataSeries11.ChartType = [System.Windows.Forms.DataVisualization.Charting.SeriesChartType]::Line
$dataSeries11.BorderWidth = 2
$dataSeries11.Color = [System.Drawing.Color]::Green

$dataSeries21 = New-Object System.Windows.Forms.DataVisualization.Charting.Series
$dataSeries21.Name = "Sequential Write"
$dataSeries21.XValueType = [System.Windows.Forms.DataVisualization.Charting.ChartValueType]::String
$dataSeries21.YValueType = [System.Windows.Forms.DataVisualization.Charting.ChartValueType]::Double
$dataSeries21.ChartType = [System.Windows.Forms.DataVisualization.Charting.SeriesChartType]::Line
$dataSeries21.BorderWidth = 2
$dataSeries21.Color = [System.Drawing.Color]::Magenta
$dataSeries21.YAxisType = [System.Windows.Forms.DataVisualization.Charting.AxisType]::Secondary  # Set YAxisType to Secondary

# Create the first Y-axis
$yAxis1 = $chart.ChartAreas[0].AxisY
$yAxis1.Title = "IOPS"
$yAxis1.MajorGrid.Enabled = $false
$yAxis1.LabelStyle.Format = "0"
$yAxis1.Maximum = $maxYValue

# Create the second Y-axis
$yAxis2 = $chart.ChartAreas[0].AxisY2
$yAxis2.Title = "MB/sec"
$yAxis2.MajorGrid.Enabled = $false
$yAxis2.LabelStyle.Format = "0"
$yAxis2.Maximum = $maxY2Value

$ChartTitle = New-Object System.Windows.Forms.DataVisualization.Charting.Title
$ChartTitle.Text = 'Sequential =Mb/Sec (yellow,Magenta) / IO = IOPS count (Green,BLue)'
$Font = New-Object System.Drawing.Font @('Microsoft Sans Serif','9', [System.Drawing.FontStyle]::Bold)
$ChartTitle.Font =$Font
$Chart.Titles.Add($ChartTitle)


foreach ($item in $read_combined_ran) {
    $blocks= $item."blocks"
    $access = $item.Access
    #$mb_sec = $item."MB/sec"
    $iops = $item.IOPS
    
    if ($access -eq "Random") {
        $dataSeries1.Points.AddXY($Blocks,$iops)
    } 
}
 
foreach ($item in $Read_combined_seq) {
    $access = $item.Access
    $mb_sec = $item."MB/sec"
    $blocks = $item."Blocks"
   # $iops = $item.IOPS

    if ($access -like "Sequential") {
        $dataSeries2.Points.AddXY($blocks, $mb_sec)
    }
        
   
}

foreach ($item in $write_combined_ran) {
    $access = $item.Access
    $iops = $item.IOPS
    $blocks = $item."Blocks"

    if ($access -eq "Random") {
        $dataSeries11.Points.AddXY($Blocks, $iops)
    }
}

foreach ($item in $Write_combined_seq) {
    $access = $item.Access
    $mb_sec = $item."MB/sec"
    $blocks = $item."Blocks"
    if ($access -eq "Sequential") {
        Write-Host "Adding sequential write data point: Blocks=$blocks, MB/sec=$mb_sec"
        $dataSeries21.Points.AddXY($Blocks, $mb_sec)
    }
}


$chart.Series.Add($dataSeries1)
$chart.Series.Add($dataSeries2)

$chart.Series.Add($dataSeries11)
$chart.Series.Add($dataSeries21)

 

$chart.SaveImage("$mydir\Graphall.png", [System.Drawing.Imaging.ImageFormat]::Png)
Write-host " You must close the form to move forward in application. " -ForegroundColor Green
#$combined_data | ConvertTo-Json | Out-File "$mydir\data.json" -Append
$read_combined_ran | ConvertTo-Json | Out-File "$mydir\Graphall.json" -Append
$Read_combined_seq | ConvertTo-Json | Out-File "$mydir\Graphall.json" -Append
$write_combined_ran | ConvertTo-Json | Out-File "$mydir\Graphall.json" -Append
$Write_combined_seq | ConvertTo-Json | Out-File "$mydir\Graphall.json" -Append


## Rule For Sequential IO - THROUGHPUT Don’t worry about the IO- Only the throughput matters
### Rule	For Random IO- Only IOPS matters- don’t worry about throughput 



$chartForm = New-Object System.Windows.Forms.Form
$chartForm.SuspendLayout()
$chart.Dock = [System.Windows.Forms.DockStyle]::Fill
$chartForm.Controls.Add($chart)
$chartForm.ResumeLayout()



 


# Show the form
 

# ... (rest of the Graphall function)

# Show the form
$chartForm.ShowDialog()

# Set the PictureBox's Image property to the newly generated chart image
$pictureBoxImage.Image = [System.Drawing.Image]::FromFile("$mydir\Graphall.png")

 

$pictureBoxImage.Image.close()
$pictureBoxImage.Image.dispose()
$chartform.close()
$chartform.dispose()


}

function corner1  {

        param (
       [string]$global:disk
    )
# Drive performance Report Generator
# by Arnaud TORRES
# Microsoft provides script, macro, and other code examples for illustration only, without warranty either expressed or implied, including but not
# limited to the implied warranties of merchantability and/or fitness for a particular purpose. This script is provided 'as is' and Microsoft does not
# guarantee that the following script, macro, or code can be used in all situations.
# Script will stress your computer CPU and storage, be sure that no critical workload is running
 
# Clear screen
#$loco= set-location -Path $PSScriptRoot
#$mypath = $MyInvocation.MyCommand.path
#$mydir = split-path $mypath -Parent

#Set-Location -Path $mydir
#$loco= set-location -Path $PSScriptRoot
 
 $null = ""
 $disk = $global:disk

 

if ($disk -eq $null ){"Wrong drive letter format used, please specify the drive as D:"
Exit}

if ($disk.substring(1,1) -eq ":"){"Wrong drive letter format used, please specify the drive as D:"
Exit}

$disk = $disk.ToUpper()

# Reset test counter
$counter = 0

# Use 1 thread / core
$Thread = "-t"+(Get-WmiObject win32_processor).NumberofCores

# Set time in seconds for each run
# 10-120s is fine
$Time = "-d60"

# Outstanding IOs
# Should be 2 times the number of disks in the RAID
# Between  8 and 16 is generally fine
$OutstandingIO = "-o16"

# Disk preparation
# Delete testfile.dat if it exists
# The test will use all free space -2GB
 $IsDir = test-path -path "$disk\TestDiskSpd"
 

 
if ($IsDir -like "False"){new-item -itemtype directory -path "$global:disk\TestDiskSpd\"}

# Just a little security, in case we are working on a compressed drive ...
compact /u /s $disk\TestDiskSpd\

$Cleaning = test-path -path "$disk\TestDiskSpd\testfile.dat"
if ($Cleaning -eq "True")
{"Removing current testfile.dat from drive"
remove-item $disk\TestDiskSpd\testfile.dat}

 $mydisks = $Global:Disk
$mydisks1 = Get-WmiObject win32_logicaldisk
$mydisks
$LogicalDisk = $mydisks1 | where {$_.DeviceID -eq "$mydisks"}
$Freespace = $LogicalDisk.freespace
$FreespaceGB = [int]($Freespace / 1073741824)
if($FreespaceGB -gt 6){
[int]$Capacity = 12
}
#if($Capacity -ne 12){
#Write-host "Not enough free space ($freespaceGB), need at least 6GB";Exit}

$CapacityParameter = "-c"+$Capacity+"G"
$CapacityO = $Capacity * 1073741824
#if ($FreespaceGB -lt "4"){
#"Not enough space on the Disk ! More than 4GB needed"}

Write-host " "
$Continue = Read-Host "You are about to test $disk , do you wan't to continue ? (Y/N) "
if ($continue -ne "y" -or $continue -ne "Y"){"Test Cancelled !!"
Exit}

# Construct the full target path based on UNC or drive letter
if ($global:disk -like "\\*") {
    $targetFile = "$global:disk\TestDiskSpd\testfile.dat"
} else {
    $targetFile = Join-Path "$global:disk\TestDiskSpd" "testfile.dat"
}


# Ensure target directory exists, uncompress if needed, and clean up any previous testfile
$dirPath = Split-Path $targetFile -Parent
if (-not (Test-Path $dirPath)) {
    New-Item -ItemType Directory -Path $dirPath -Force
}
compact /u /s "$dirPath\"
if (Test-Path $targetFile) {
    Remove-Item $targetFile -Force
}


"Initialization can take some time, we are generating a $Capacity GB file..."

"  "
# Initialize outpout file
$date = get-date

# Add the tested disk and the date in the output file
$servicetag= (get-wmiobject win32_systemEnclosure).SerialNumber
$dinfo = (get-volume).Size														   

 

# Get the current date and time
$date = Get-Date

# Convert to regular time format with AM/PM
$regularTime = $date.ToString("hh-mm-ss tt")

# Content to write to the file
$content = "Disk $disk, $date, $servicetag, $dinfo"  

# Specify the file path and name using the variable
$filePath = "$mydir\$regularTime.txt"

# Create the file and write the content
$content | Out-File -FilePath $filePath


# Add the headers to the output file - stops graph from working 
“Test N#, Drive, Operation, Access, Blocks, Run N#, IOPS, MB/sec, Latency ms, CPU %" >> ./output.txt

# Number of tests
# Multiply the number of loops to change this value
# By default there are : (4 blocks sizes) X (2 for read 100% and write 100%) X (2 for Sequential and Random) X (4 Runs of each)

$NumberOfTests = 16


write-host "TEST RESULTS (also logged in .\output.txt)" -foregroundcolor yellow

# Begin Tests loops
# We will run the tests with 4K, 8K, 64K and 512K blocks

 
							   
							

do {
    (4, 8, 64, 512) | ForEach-Object {
        $BlockParameter = ("-b" + $_ + "K")
        $Blocks = ("Blocks " + $_ + "K")

        # We will do Read tests and Write tests
        (0, 100) | ForEach-Object {
            if ($_ -eq 0) { $IO = "Read" }
            if ($_ -eq 100) { $IO = "Write" }
            $WriteParameter = "-w" + $_

            # We will do random and sequential IO tests
            ("r", "si") | ForEach-Object {
                if ($_ -eq "r") { $type = "Random" }
                if ($_ -eq "si") { $type = "Sequential" }
                $AccessParameter = "-" + $_

                # Each run will be done 4 times
                (1..1) | ForEach-Object {
                    # The test itself (finally!!)
                    $result = .\diskspd.exe $CapacityPArameter $Time $AccessParameter $WriteParameter $Thread $OutstandingIO $BlockParameter -h -L $targetFile

                    # Now we will break the very verbose output of DiskSpd in a single line with the most important values
                    foreach ($line in $result) { if ($line -like "*total:*") { $total = $line; break } }
                    foreach ($line in $result) { if ($line -like "*avg.*") { $avg = $line; break } }
                    $mbps = $total.Split("|")[2].Trim()
                    $iops = $total.Split("|")[3].Trim()
                    $latency = $total.Split("|")[4].Trim()
                    $cpu = $avg.Split("|")[1].Trim()
                    $counter = $counter + 1

                    # A progress bar, for the fun
                    Write-Progress -Activity ".\diskspd.exe $CapacityPArameter $Time $AccessParameter $WriteParameter $Thread $OutstandingIO $BlockParameter -h -L $targetFile" -status "Test in progress" -percentComplete ($counter / ($NumberofTests) * 100)    

                    # Remove comment to check command line ".\diskspd.exe $CapacityPArameter $Time $AccessParameter $WriteParameter $Thread -$OutstandingIO $BlockParameter -h -L $global:disk\TestDiskSpd\testfile.dat"
                    # We output the values to the text file
					$testcost.text =    "Test $Counter,$global:disk,$IO,$type,$Blocks,Run $_,$iops,$mbps,$latency,$cpu"  
                
               

               $output = "Test $Counter,$global:disk,$IO,$type,$Blocks,Run $_,$iops,$mbps,$latency,$cpu"
                  Write-Output $output
                    Add-Content -Path ./output.txt -Value $output


                    # We output a verbose format on screen
               write-host "Test $Counter, $global:disk, $IO, $type, $Blocks, Run $_, $iops iops, $mbps MB/sec, $latency ms, $cpu CPU"

                }

            }

        }

    }

    # Calculate the percentage completed based on the total number of tests and the current counter value
    $percentComplete = [Math]::Round(($counter / $NumberOfTests ) * 100)

} while ($counter -lt $NumberOfTests)

Write-Progress -Activity ".\diskspd.exe $CapacityPArameter $Time $AccessParameter $WriteParameter $Thread $OutstandingIO $BlockParameter -h -L $targetFile" -status "Ready" -Completed  
Write-host " Testing is complete. You may have to restart the application and chose the Open Graph Button."

}


Function actualcorner {
    param (
    [string]$disk
)
$global:disk = $disk

    Write-Host "$global:disk is $global:disk is working as designed"

    $loco = Set-Location -Path $PSScriptRoot

    Write-Host "DRIVE PERFORMANCE REPORT GENERATOR" -ForegroundColor Green
    Write-Host "Script will stress your computer CPU and storage layer (including network if applicable!), be sure that no critical workload is running" -ForegroundColor Yellow
    Write-Host "Microsoft provides script, macro, and other code examples for illustration only, without warranty either expressed or implied..." -ForegroundColor Yellow
    Write-Host "Test will use all free space on drive minus 2 GB!"
    Write-Host "If there are less than 4 GB free test will stop"

    if (-not $global:disk) {
    Write-Host "[DEBUG] ERROR: \$global:disk is empty or undefined." -ForegroundColor Red
}
Write-Host "Entered Subroutine test module for disk: $global:disk"

    Rename-Item -Path output.txt -NewName dat.csv -Force -WarningAction SilentlyContinue -ErrorAction SilentlyContinue

    $path = $global:disk

    # Normalize backslashes
    $path = $path.TrimEnd('\')

    # Fix: Allow \localhost or \\machinename paths
    if ($path -match "^\\\\[^\\]+\\.+") {
        $global:disk = $path
        Write-Host "Using UNC path: $global:disk"
        Write-Host "Skipping free space check. Assuming 24 GB available on target."
        $FreespaceGB = 24
    }
    elseif ($path -match "^[a-zA-Z]:\\?$") {
        $global:disk = $path
        Write-Host "Using drive letter: $global:disk"
        try {
            $vol = Get-CimInstance Win32_LogicalDisk -Filter "DeviceID = '$global:disk'"
        } catch {
            Write-Host "Error querying WMI: $_"
            Exit
        }

        if (-not $vol) {
            Write-Host "Invalid drive letter: $global:disk"
            Exit
        }

        $Freespace = $vol.FreeSpace
        $FreespaceGB = [int]($Freespace / 1073741824)
        Write-Host "Sufficient free space available: $FreespaceGB GB"
    }
    else {
        Write-Host "Invalid path input. Please use a drive letter like C: or UNC like \\localhost\share."
        Exit
    }

    if ($FreespaceGB -lt 6) {
        Write-Host "Not enough free space ($FreespaceGB GB), need at least 6GB"
        Exit
    }

    $Capacity = if ($FreespaceGB -ge 6) { 6 } else { $FreespaceGB }
    $CapacityParameter = "-c" + $Capacity + "G"
    $CapacityO = $Capacity * 1073741824

    if ($FreespaceGB -lt 4) {
        Write-Host "Not enough space on the disk! More than 4GB needed."
        Exit
    }

    Write-Host " "
    $Continue = Read-Host "You are about to test $global:disk which has $FreespaceGB GB free, do you want to continue? (Y/N)"
    if ($Continue -ne "y" -and $Continue -ne "Y") {
        Write-Host "Test Cancelled!!"
        Exit
    }

    if ($global:disk -like "\\*") {
        $targetFile = "$global:disk\\testfile.dat"
    } else {
        $targetFile = Join-Path "$global:disk\\TestDiskSpd" "testfile.dat"
    }

    $dirPath = Split-Path $targetFile -Parent
    if (-not (Test-Path $dirPath)) {
        New-Item -ItemType Directory -Path $dirPath -Force
    }
    compact /u /s "$dirPath\"
    if (Test-Path $targetFile) {
        Remove-Item $targetFile -Force
    }

    Write-Host "Initialization can take some time, we are generating a $Capacity GB file..."

    $date = Get-Date
    $servicetag = (Get-WmiObject Win32_SystemEnclosure).SerialNumber
    $dinfo = (Get-Volume).Size
    "Test N#, Drive, Operation, Access, Blocks, Run N#, IOPS, MB/sec, Latency ms, CPU %" >> ./output.txt

    $NumberOfTests = 16
    Write-Host "TEST RESULTS (also logged in .\output.txt)" -ForegroundColor Yellow

    do {
        (4, 8, 64, 512) | ForEach-Object {
            $BlockParameter = ("-b" + $_ + "K")
            $Blocks = ("Blocks " + $_ + "K")

            (0, 100) | ForEach-Object {
                $IO = if ($_ -eq 0) { "Read" } else { "Write" }
                $WriteParameter = "-w" + $_

                ("r", "si") | ForEach-Object {
                    $type = if ($_ -eq "r") { "Random" } else { "Sequential" }
                    $AccessParameter = "-" + $_

                    (1..1) | ForEach-Object {
                        $result = .\diskspd.exe $CapacityParameter $Time $AccessParameter $WriteParameter $Thread $OutstandingIO $BlockParameter -h -L $targetFile

                        foreach ($line in $result) { if ($line -like "*total:*") { $total = $line; break } }
                        foreach ($line in $result) { if ($line -like "*avg.*") { $avg = $line; break } }

                        $mbps = $total.Split("|")[2].Trim()
                        $iops = $total.Split("|")[3].Trim()
                        $latency = $total.Split("|")[4].Trim()
                        $cpu = $avg.Split("|")[1].Trim()
                        $counter++

                        Write-Progress -Activity ".\diskspd.exe $CapacityParameter $Time $AccessParameter $WriteParameter $Thread $OutstandingIO $BlockParameter -h -L $targetFile" -Status "Test in progress" -PercentComplete ($counter / $NumberOfTests * 100)

                        $output = "Test $counter,$global:disk,$IO,$type,$Blocks,Run $_,$iops,$mbps,$latency,$cpu"
                        Write-Output $output
                        Add-Content -Path ./output.txt -Value $output

                        Write-Host "Test $counter, $global:disk, $IO, $type, $Blocks, Run $_, $iops IOPS, $mbps MB/sec, $latency ms, $cpu CPU"
                    }
                }
            }
        }
        $percentComplete = [Math]::Round(($counter / $NumberOfTests) * 100)
    } while ($counter -lt $NumberOfTests)

    Write-Progress -Activity ".\diskspd.exe $CapacityParameter $Time $AccessParameter $WriteParameter $Thread $OutstandingIO $BlockParameter -h -L $targetFile" -Status "Ready" -Completed
    Write-Host "Testing is complete. You may have to restart the application and choose the Open Graph Button."

    Rename-Item -Path "output.txt" -NewName "dat.csv" -Force -ErrorAction SilentlyContinue -WarningAction SilentlyContinue
}
 






Function Calculations {

$mydownloads = (New-Object -ComObject Shell.Application).NameSpace('shell:Downloads').Self.Path
$myscriptloc = $PSScriptRoot
$mydir = "$mydownloads\CornersTestandGraph2.0\"
Set-Location -path  "$mydownloads\CornersTestandGraph2.0\"
3
 
Rename-Item -Path output.txt -NewName dat.csv -force
 
Rename-Item -Path "output.txt" -NewName "dat.csv" -Force -ErrorAction SilentlyContinue -WarningAction SilentlyContinue


if (!($data))
{ $data = Import-Csv -Path "$mydir\dat.csv" -ErrorAction SilentlyContinue -WarningAction SilentlyContinue; Sleep(3)}


# Filter the data to include only rows where the Operation column contains "Read"
$read_data = $data | Where-Object { $_.Operation -like "*Read*" }
sleep (3)

 


# Split the data into two sets based on the Access column
$read_random_access_data = $read_data | Where-Object { $_.Access -like "*Random*" }
$read_sequential_access_data = $read_data | Where-Object { $_.Access -like "*Sequential*" }

#########test random read and sequential read data 
$read_random_access_data | ft
$read_sequential_access_data | ft

# Combine the two sets of data and create a new property to identify the access type
$read_combined_ran = $read_random_access_data | Select-Object @{Name="Access";Expression={"Random"}},Blocks,IOPS
$Read_combined_seq = $read_sequential_access_data | Select-Object @{Name="Access";Expression={"Sequential"}},Blocks,MB/sec

##### FILTER THE DATA FOR WRITE DATA 
# Filter the data to include only rows where the Operation column contains "Write"
 $write_data = $data | Where-Object { $_.Operation -like "*Write*" }

# Split the data into two sets based on the Access column
$random_write_access_data = $write_data | Where-Object { $_.Access -like "Random" }
$sequential_write_access_data = $write_data | Where-Object { $_.Access -like "Sequential" }

# Combine the two sets of data and create a new property to identify the access type
$write_combined_ran = $random_write_access_data | Select-Object @{Name="Access";Expression={"Random"}},Blocks,IOPS
$Write_combined_seq = $sequential_write_access_data | Select-Object @{Name="Access";Expression={"Sequential"}},Blocks,MB/sec

#### test random and sequentual writes 
#$write_combined_ran | ft
#$Write_combined_seq | ft
$random_write_access_data | ft
$sequential_write_access_data | ft


#### FINISH FILTER FOR WRITE DATA 
# Calculate the maximum Y-value for all data points
# Find the largest value for IOPS in each dataset
$maxIOPS_read_ran = $read_combined_ran.IOPS | Measure-Object -Maximum | Select-Object -ExpandProperty Maximum
$maxIOPS_read_seq = $Read_combined_seq.IOPS | Measure-Object -Maximum | Select-Object -ExpandProperty Maximum
$maxIOPS_write_ran = $write_combined_ran.IOPS | Measure-Object -Maximum | Select-Object -ExpandProperty Maximum
$maxIOPS_write_seq = $Write_combined_seq.IOPS | Measure-Object -Maximum | Select-Object -ExpandProperty Maximum

# Find the largest value for MB/sec in each dataset
$maxMBSec_read_seq = $Read_combined_seq."MB/sec" | Measure-Object -Maximum | Select-Object -ExpandProperty Maximum
$maxMBSec_write_seq = $Write_combined_seq."MB/sec" | Measure-Object -Maximum | Select-Object -ExpandProperty Maximum

# the format has to be just like below
# Test N#	 Drive	 Operation	 Access	 Blocks	 Run N#	 IOPS	 MB/sec	 Latency ms	 CPU %
# place the numbers in the csv as csv or space seperated values 

# set path asap 
$mypath = $MyInvocation.MyCommand.path
$mydir = split-path $mypath -Parent

Set-Location -Path $mydir

$mydownloads = (New-Object -ComObject Shell.Application).NameSpace('shell:Downloads').Self.Path
$myscriptloc = $PSScriptRoot
Set-Location  "$mydownloads\CornersTestandGraph2.0\"
$mydir = $pwd
Clear-Host
#Write-host "The CSV file needs to be in this folder. It also must be in the proper format like the dat.csv"
#write-host "Failure to do those things will result in you getting nothing valuable from this forray" -BackgroundColor Green
#$keypressed = "dat.csv"
#$keybus = Read-host "enter the name of the file you want me to do your work for you on. Enter=dat.csv"

#if ([bool] $keybus -eq $true) {$keypressed = $keybus} else {$keypressed = "dat.csv"}
 
  

# Filter the data to include only rows where the Operation column contains "Read"
$read_data = $data | Where-Object { $_.Operation -like "*Read*" }


# Split the data into two sets based on the Access column
$read_random_access_data = $read_data | Where-Object { $_.Access -like "*Random*" }
$read_sequential_access_data = $read_data | Where-Object { $_.Access -like "*Sequential*" }

#########test random read and sequential read data 
$read_random_access_data | ft
$read_sequential_access_data | ft

# Combine the two sets of data and create a new property to identify the access type
$read_combined_ran = $read_random_access_data | Select-Object @{Name="Access";Expression={"Random"}},Blocks,IOPS
$Read_combined_seq = $read_sequential_access_data | Select-Object @{Name="Access";Expression={"Sequential"}},Blocks,MB/sec

##### FILTER THE DATA FOR WRITE DATA 
# Filter the data to include only rows where the Operation column contains "Write"
 $write_data = $data | Where-Object { $_.Operation -like "*Write*" }

# Split the data into two sets based on the Access column
$random_write_access_data = $write_data | Where-Object { $_.Access -like "Random" }
$sequential_write_access_data = $write_data | Where-Object { $_.Access -like "Sequential" }

# Combine the two sets of data and create a new property to identify the access type
$write_combined_ran = $random_write_access_data | Select-Object @{Name="Access";Expression={"Random"}},Blocks,IOPS
$Write_combined_seq = $sequential_write_access_data | Select-Object @{Name="Access";Expression={"Sequential"}},Blocks,MB/sec

#### test random and sequentual writes 
#$write_combined_ran | ft
#$Write_combined_seq | ft
$random_write_access_data | ft
$sequential_write_access_data | ft


#### FINISH FILTER FOR WRITE DATA 
# Calculate the maximum Y-value for all data points
# Find the largest value for IOPS in each dataset
$maxIOPS_read_ran = $read_combined_ran.IOPS | Measure-Object -Maximum | Select-Object -ExpandProperty Maximum
$maxIOPS_read_seq = $Read_combined_seq.IOPS | Measure-Object -Maximum | Select-Object -ExpandProperty Maximum
$maxIOPS_write_ran = $write_combined_ran.IOPS | Measure-Object -Maximum | Select-Object -ExpandProperty Maximum
$maxIOPS_write_seq = $Write_combined_seq.IOPS | Measure-Object -Maximum | Select-Object -ExpandProperty Maximum

# Find the largest value for MB/sec in each dataset
$maxMBSec_read_seq = $Read_combined_seq."MB/sec" | Measure-Object -Maximum | Select-Object -ExpandProperty Maximum
$maxMBSec_write_seq = $Write_combined_seq."MB/sec" | Measure-Object -Maximum | Select-Object -ExpandProperty Maximum
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

$global:form = New-Object System.Windows.Forms.Form

# Calculate the maximum Y-value by finding the largest value among all datasets
$maxYValue = ($maxIOPS_read_ran, $maxIOPS_read_seq, $maxIOPS_write_ran, $maxIOPS_write_seq) | Measure-Object -Maximum | Select-Object -ExpandProperty Maximum
$maxY2Value = ($maxMBSec_read_seq, $maxMBSec_write_seq) | Measure-Object -Maximum | Select-Object -ExpandProperty Maximum

}


#### Start Program 

#dealwith file if its available 

$data= $null

# the format has to be just like below
# Test N#	 Drive	 Operation	 Access	 Blocks	 Run N#	 IOPS	 MB/sec	 Latency ms	 CPU %
# place the numbers in the csv as csv or space seperated values 
 cls

$mydownloads = (New-Object -ComObject Shell.Application).NameSpace('shell:Downloads').Self.Path
$myscriptloc = $PSScriptRoot
$mydir = "$mydownloads\CornersTestandGraph2.0\"
Set-Location -path  "$mydownloads\CornersTestandGraph2.0\"

 

if (test-path "dat.old" ) {Remove-item dat.old -force}
 
 #if (test-path -Path output.txt) { Remove-Item "output.txt" -Force}
  
 if (test-path -Path $mydir\dat.csv) { 
    
        Write-host "Dat.Csv found. "
    $ands1 = read-host "delete old files? y or n"
  if ($ands1 -eq "y")
  {  remove-item  dat.csv ; sleep(2) 
    remove-Item output.txt -force
    remove-item graphall.png -force
    
    } ; sleep (3)
    
    }
  

  # Load the data from a CSV file
#$data = Import-Csv -Path "$mydir\dat.csv"

#Sleep(3)

  


  ##ENd file check 

$mydownloads = (New-Object -ComObject Shell.Application).NameSpace('shell:Downloads').Self.Path
$myscriptloc = $PSScriptRoot
Set-Location  "$mydownloads\CornersTestandGraph2.0\"
  $ErrorActionPreference = 'silentlycontinue'
 $WarningPreference = 'silentlycontinue'
 

$mydownloads = (New-Object -ComObject Shell.Application).NameSpace('shell:Downloads').Self.Path
$myscriptloc = $PSScriptRoot


Write-host "Welcome to 4 corners storage test baseline"
 
Set-Location "$mydownloads\CornersTestandGraph2.0\"
 if (test-path -Path "diskspd.__e") {Rename-Item -Path "diskspd.__e" -NewName "diskspd.exe"}
#Rename-Item -Path "DskSpd4C.ps1.renameme" -NewName "DskSpd4C.ps1"
Clear
Write-host "4Corners" -ForegroundColor Green
Write-host "Choose drive letter of concern, even if we are just grabbing a graph" -ForegroundColor Yellow

$Global:Disk = read-host "Choose storage C:\ClusterStorage\Volume1 or \\fileserver\share or S: with colone but without ending \"
 
Write-host " Spinning up Test engine.. Please wait.. "
Write-host " You chose to run test on $Global:Disk"
# \\localhost\c$\Dell\temp\

#actualcorner
#corner1
clear
function Show-Menu
{
    param (
        [string]$Title = 'Menu For OMIMSWAC Help'
    )
     $os = Get-CimInstance win32_operatingsystem
$alval  = $os | Select-Object CSName,LastBootUpTime, @{Name="Uptime";Expression={(Get-Date) - $_.lastbootuptime}}
    
  

     Clear-Host
    
  Write-Host “================ Drive test $Global:disk ================”

Write-Host “1: Press ‘1’ Option #1 Test 1”
Write-Host “2: Press ‘2’ Option #2 Calculations for screen”
Write-Host “3: Press ‘3’ Option #3 Calculations and graph (only on a GUI machine)”
Write-Host “Q: Press ‘Q’ to quit.”
}





 
 
 do
 {
     Show-Menu
    Write-Host “================ Drive test $Global:disk ================”
     $selection = Read-Host "Type the Desired menu test to run on disk $Global:Disk, item and hit enter or q to quit"
     switch ($selection)
     {
         '1' {
             'Option #1 Graph 1'
             actualcorner -disk $global:disk
         } '2' {
             'Option # Calculations 2'
             calculations
         } '3' {
             'Option #3 Draw Graph 3'
             Graphall 
         }
     }
     pause
 }
 until ($selection -eq 'q')

   
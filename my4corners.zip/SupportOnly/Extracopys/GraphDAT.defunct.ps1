﻿
### THIS IS FOR NOSTALGIA ONLY - THIS WAS MY FIRST BIG PROJECT AND IT SUCKS BUT IT WAS MINE> and i am keeping it :-) 
if (!([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    Start-Process PowerShell -Verb RunAs "-NoProfile -ExecutionPolicy Bypass -Command `"cd '$pwd'; & '$PSCommandPath';`"";
    exit;
}


function closeall 

{
$form.close()
$form.dispose()

}
$mydownloads = (New-Object -ComObject Shell.Application).NameSpace('shell:Downloads').Self.Path
$myscriptloc = $PSScriptRoot
Set-Location  "$mydownloads\CornersTestandGraph2.0\"
  $ErrorActionPreference = 'silentlycontinue'
 $WarningPreference = 'silentlycontinue'

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

$global:form = New-Object System.Windows.Forms.Form

$ErrorActionPreference = 'SilentlyContinue'
 $WarningPreference = 'SilentlyContinue'



### graphing apps 


Function Graphall 
{

  param (
        [string]$text,
        [string]$global:disk
    )


$data= $null

# the format has to be just like below
# Test N#	 Drive	 Operation	 Access	 Blocks	 Run N#	 IOPS	 MB/sec	 Latency ms	 CPU %
# place the numbers in the csv as csv or space seperated values 
Add-Type -AssemblyName System.Windows.Forms
 Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Windows.Forms.DataVisualization

$mydownloads = (New-Object -ComObject Shell.Application).NameSpace('shell:Downloads').Self.Path
$myscriptloc = $PSScriptRoot
$mydir = "$mydownloads\CornersTestandGraph2.0\"
Set-Location -path  "$mydownloads\CornersTestandGraph2.0\"

# Get all PNG files in the directory (excluding "example.png")
$pngFiles = Get-ChildItem -Path $mydir -Filter "*.png" | Where-Object { $_.Name -ne "example.png" }

# Do something with the selected PNG files (e.g., process them or display their names)
If (!($pngFiles)) { 
$timecost.text = "Intake new Job..."

if (test-path -Path dat.old ) {del dat.old -force}
 
 if (test-path -Path output.txt) {
  
    if (test-path -Path $mydir\dat.csv) { Rename-Item -Path dat.csv -NewName dat.old -force; sleep(2) }
    Rename-Item -Path output.txt -NewName dat.csv -force ; sleep (3)
  }

  # Load the data from a CSV file
$data = Import-Csv -Path "$mydir\dat.csv"

Sleep(3)

  }


if (!($data))
{ $data = Import-Csv -Path "$mydir\dat.csv" -ErrorAction SilentlyContinue -WarningAction SilentlyContinue; Sleep(3)}



 
 

# Filter the data to include only rows where the Operation column contains "Read"
$read_data = $data | Where-Object { $_.Operation -like "*Read*" }
sleep (3)

 


# Split the data into two sets based on the Access column
$read_random_access_data = $read_data | Where-Object { $_.Access -like "*Random*" }
$read_sequential_access_data = $read_data | Where-Object { $_.Access -like "*Sequential*" }

#########test random read and sequential read data 
$read_random_access_data | ft
$read_sequential_access_data | ft

# Combine the two sets of data and create a new property to identify the access type
$read_combined_ran = $read_random_access_data | Select-Object @{Name="Access";Expression={"Random"}},Blocks,IOPS
$Read_combined_seq = $read_sequential_access_data | Select-Object @{Name="Access";Expression={"Sequential"}},Blocks,MB/sec

##### FILTER THE DATA FOR WRITE DATA 
# Filter the data to include only rows where the Operation column contains "Write"
 $write_data = $data | Where-Object { $_.Operation -like "*Write*" }

# Split the data into two sets based on the Access column
$random_write_access_data = $write_data | Where-Object { $_.Access -like "Random" }
$sequential_write_access_data = $write_data | Where-Object { $_.Access -like "Sequential" }

# Combine the two sets of data and create a new property to identify the access type
$write_combined_ran = $random_write_access_data | Select-Object @{Name="Access";Expression={"Random"}},Blocks,IOPS
$Write_combined_seq = $sequential_write_access_data | Select-Object @{Name="Access";Expression={"Sequential"}},Blocks,MB/sec

#### test random and sequentual writes 
#$write_combined_ran | ft
#$Write_combined_seq | ft
$random_write_access_data | ft
$sequential_write_access_data | ft


#### FINISH FILTER FOR WRITE DATA 
# Calculate the maximum Y-value for all data points
# Find the largest value for IOPS in each dataset
$maxIOPS_read_ran = $read_combined_ran.IOPS | Measure-Object -Maximum | Select-Object -ExpandProperty Maximum
$maxIOPS_read_seq = $Read_combined_seq.IOPS | Measure-Object -Maximum | Select-Object -ExpandProperty Maximum
$maxIOPS_write_ran = $write_combined_ran.IOPS | Measure-Object -Maximum | Select-Object -ExpandProperty Maximum
$maxIOPS_write_seq = $Write_combined_seq.IOPS | Measure-Object -Maximum | Select-Object -ExpandProperty Maximum

# Find the largest value for MB/sec in each dataset
$maxMBSec_read_seq = $Read_combined_seq."MB/sec" | Measure-Object -Maximum | Select-Object -ExpandProperty Maximum
$maxMBSec_write_seq = $Write_combined_seq."MB/sec" | Measure-Object -Maximum | Select-Object -ExpandProperty Maximum

# the format has to be just like below
# Test N#	 Drive	 Operation	 Access	 Blocks	 Run N#	 IOPS	 MB/sec	 Latency ms	 CPU %
# place the numbers in the csv as csv or space seperated values 

# set path asap 
$mypath = $MyInvocation.MyCommand.path
$mydir = split-path $mypath -Parent

Set-Location -Path $mydir

$mydownloads = (New-Object -ComObject Shell.Application).NameSpace('shell:Downloads').Self.Path
$myscriptloc = $PSScriptRoot
Set-Location  "$mydownloads\CornersTestandGraph2.0\"
$mydir = $pwd
Clear-Host
#Write-host "The CSV file needs to be in this folder. It also must be in the proper format like the dat.csv"
#write-host "Failure to do those things will result in you getting nothing valuable from this forray" -BackgroundColor Green
#$keypressed = "dat.csv"
#$keybus = Read-host "enter the name of the file you want me to do your work for you on. Enter=dat.csv"

#if ([bool] $keybus -eq $true) {$keypressed = $keybus} else {$keypressed = "dat.csv"}
 
  

# Filter the data to include only rows where the Operation column contains "Read"
$read_data = $data | Where-Object { $_.Operation -like "*Read*" }


# Split the data into two sets based on the Access column
$read_random_access_data = $read_data | Where-Object { $_.Access -like "*Random*" }
$read_sequential_access_data = $read_data | Where-Object { $_.Access -like "*Sequential*" }

#########test random read and sequential read data 
$read_random_access_data | ft
$read_sequential_access_data | ft

# Combine the two sets of data and create a new property to identify the access type
$read_combined_ran = $read_random_access_data | Select-Object @{Name="Access";Expression={"Random"}},Blocks,IOPS
$Read_combined_seq = $read_sequential_access_data | Select-Object @{Name="Access";Expression={"Sequential"}},Blocks,MB/sec

##### FILTER THE DATA FOR WRITE DATA 
# Filter the data to include only rows where the Operation column contains "Write"
 $write_data = $data | Where-Object { $_.Operation -like "*Write*" }

# Split the data into two sets based on the Access column
$random_write_access_data = $write_data | Where-Object { $_.Access -like "Random" }
$sequential_write_access_data = $write_data | Where-Object { $_.Access -like "Sequential" }

# Combine the two sets of data and create a new property to identify the access type
$write_combined_ran = $random_write_access_data | Select-Object @{Name="Access";Expression={"Random"}},Blocks,IOPS
$Write_combined_seq = $sequential_write_access_data | Select-Object @{Name="Access";Expression={"Sequential"}},Blocks,MB/sec

#### test random and sequentual writes 
#$write_combined_ran | ft
#$Write_combined_seq | ft
$random_write_access_data | ft
$sequential_write_access_data | ft


#### FINISH FILTER FOR WRITE DATA 
# Calculate the maximum Y-value for all data points
# Find the largest value for IOPS in each dataset
$maxIOPS_read_ran = $read_combined_ran.IOPS | Measure-Object -Maximum | Select-Object -ExpandProperty Maximum
$maxIOPS_read_seq = $Read_combined_seq.IOPS | Measure-Object -Maximum | Select-Object -ExpandProperty Maximum
$maxIOPS_write_ran = $write_combined_ran.IOPS | Measure-Object -Maximum | Select-Object -ExpandProperty Maximum
$maxIOPS_write_seq = $Write_combined_seq.IOPS | Measure-Object -Maximum | Select-Object -ExpandProperty Maximum

# Find the largest value for MB/sec in each dataset
$maxMBSec_read_seq = $Read_combined_seq."MB/sec" | Measure-Object -Maximum | Select-Object -ExpandProperty Maximum
$maxMBSec_write_seq = $Write_combined_seq."MB/sec" | Measure-Object -Maximum | Select-Object -ExpandProperty Maximum
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

$global:form = New-Object System.Windows.Forms.Form

# Calculate the maximum Y-value by finding the largest value among all datasets
$maxYValue = ($maxIOPS_read_ran, $maxIOPS_read_seq, $maxIOPS_write_ran, $maxIOPS_write_seq) | Measure-Object -Maximum | Select-Object -ExpandProperty Maximum
$maxY2Value = ($maxMBSec_read_seq, $maxMBSec_write_seq) | Measure-Object -Maximum | Select-Object -ExpandProperty Maximum

# Create the graph
$chart = New-Object System.Windows.Forms.DataVisualization.Charting.Chart
$chart.Width = 800
$chart.Height = 600

$chartArea = New-Object System.Windows.Forms.DataVisualization.Charting.ChartArea
$chart.ChartAreas.Add($chartArea)

$legend = New-Object System.Windows.Forms.DataVisualization.Charting.Legend
$legend.Docking = "bottom"
$chart.Legends.Add($legend)

$dataSeries1 = New-Object System.Windows.Forms.DataVisualization.Charting.Series
$dataSeries1.Name = "Random Read"
$dataSeries1.XValueType = [System.Windows.Forms.DataVisualization.Charting.ChartValueType]::String
$dataSeries1.YValueType = [System.Windows.Forms.DataVisualization.Charting.ChartValueType]::Double
$dataSeries1.ChartType = [System.Windows.Forms.DataVisualization.Charting.SeriesChartType]::Line
$dataSeries1.BorderWidth = 2
$dataSeries1.Color = [System.Drawing.Color]::Blue

$dataSeries2 = New-Object System.Windows.Forms.DataVisualization.Charting.Series
$dataSeries2.Name = "Sequential Read"
$dataSeries2.XValueType = [System.Windows.Forms.DataVisualization.Charting.ChartValueType]::String
$dataSeries2.YValueType = [System.Windows.Forms.DataVisualization.Charting.ChartValueType]::Double
$dataSeries2.ChartType = [System.Windows.Forms.DataVisualization.Charting.SeriesChartType]::Line
$dataSeries2.BorderWidth = 2
$dataSeries2.Color = [System.Drawing.Color]::Yellow
$dataSeries2.YAxisType = [System.Windows.Forms.DataVisualization.Charting.AxisType]::Secondary  # Set YAxisType to Secondary

$dataSeries11 = New-Object System.Windows.Forms.DataVisualization.Charting.Series
$dataSeries11.Name = "Random Write"
$dataSeries11.XValueType = [System.Windows.Forms.DataVisualization.Charting.ChartValueType]::String
$dataSeries11.YValueType = [System.Windows.Forms.DataVisualization.Charting.ChartValueType]::Double
$dataSeries11.ChartType = [System.Windows.Forms.DataVisualization.Charting.SeriesChartType]::Line
$dataSeries11.BorderWidth = 2
$dataSeries11.Color = [System.Drawing.Color]::Green

$dataSeries21 = New-Object System.Windows.Forms.DataVisualization.Charting.Series
$dataSeries21.Name = "Sequential Write"
$dataSeries21.XValueType = [System.Windows.Forms.DataVisualization.Charting.ChartValueType]::String
$dataSeries21.YValueType = [System.Windows.Forms.DataVisualization.Charting.ChartValueType]::Double
$dataSeries21.ChartType = [System.Windows.Forms.DataVisualization.Charting.SeriesChartType]::Line
$dataSeries21.BorderWidth = 2
$dataSeries21.Color = [System.Drawing.Color]::Magenta
$dataSeries21.YAxisType = [System.Windows.Forms.DataVisualization.Charting.AxisType]::Secondary  # Set YAxisType to Secondary

# Create the first Y-axis
$yAxis1 = $chart.ChartAreas[0].AxisY
$yAxis1.Title = "IOPS"
$yAxis1.MajorGrid.Enabled = $false
$yAxis1.LabelStyle.Format = "0"
$yAxis1.Maximum = $maxYValue

# Create the second Y-axis
$yAxis2 = $chart.ChartAreas[0].AxisY2
$yAxis2.Title = "MB/sec"
$yAxis2.MajorGrid.Enabled = $false
$yAxis2.LabelStyle.Format = "0"
$yAxis2.Maximum = $maxY2Value

$ChartTitle = New-Object System.Windows.Forms.DataVisualization.Charting.Title
$ChartTitle.Text = 'Sequential =Mb/Sec (yellow,Magenta) / IO = IOPS count (Green,BLue)'
$Font = New-Object System.Drawing.Font @('Microsoft Sans Serif','9', [System.Drawing.FontStyle]::Bold)
$ChartTitle.Font =$Font
$Chart.Titles.Add($ChartTitle)


foreach ($item in $read_combined_ran) {
    $blocks= $item."blocks"
    $access = $item.Access
    #$mb_sec = $item."MB/sec"
    $iops = $item.IOPS
    
    if ($access -eq "Random") {
        $dataSeries1.Points.AddXY($Blocks,$iops)
    } 
}
 
foreach ($item in $Read_combined_seq) {
    $access = $item.Access
    $mb_sec = $item."MB/sec"
    $blocks = $item."Blocks"
   # $iops = $item.IOPS

    if ($access -like "Sequential") {
        $dataSeries2.Points.AddXY($blocks, $mb_sec)
    }
        
   
}

foreach ($item in $write_combined_ran) {
    $access = $item.Access
    $iops = $item.IOPS
    $blocks = $item."Blocks"

    if ($access -eq "Random") {
        $dataSeries11.Points.AddXY($Blocks, $iops)
    }
}

foreach ($item in $Write_combined_seq) {
    $access = $item.Access
    $mb_sec = $item."MB/sec"
    $blocks = $item."Blocks"
    if ($access -eq "Sequential") {
        Write-Host "Adding sequential write data point: Blocks=$blocks, MB/sec=$mb_sec"
        $dataSeries21.Points.AddXY($Blocks, $mb_sec)
    }
}


$chart.Series.Add($dataSeries1)
$chart.Series.Add($dataSeries2)

$chart.Series.Add($dataSeries11)
$chart.Series.Add($dataSeries21)

 

$chart.SaveImage("$mydir\Graphall.png", [System.Drawing.Imaging.ImageFormat]::Png)
#$combined_data | ConvertTo-Json | Out-File "$mydir\data.json" -Append
$read_combined_ran | ConvertTo-Json | Out-File "$mydir\Graphall.json" -Append
$Read_combined_seq | ConvertTo-Json | Out-File "$mydir\Graphall.json" -Append
$write_combined_ran | ConvertTo-Json | Out-File "$mydir\Graphall.json" -Append
$Write_combined_seq | ConvertTo-Json | Out-File "$mydir\Graphall.json" -Append


## Rule For Sequential IO - THROUGHPUT Don’t worry about the IO- Only the throughput matters
### Rule	For Random IO- Only IOPS matters- don’t worry about throughput 



$chartForm = New-Object System.Windows.Forms.Form
$chartForm.SuspendLayout()
$chart.Dock = [System.Windows.Forms.DockStyle]::Fill
$chartForm.Controls.Add($chart)
$chartForm.ResumeLayout()



 


# Show the form
 

# ... (rest of the Graphall function)

# Show the form
$chartForm.ShowDialog()

# Set the PictureBox's Image property to the newly generated chart image
$pictureBoxImage.Image = [System.Drawing.Image]::FromFile("$mydir\Graphall.png")

 
$chartform.close()
$pictureBoxImage.Image.clost()
$pictureBoxImage.Image.dispose()
$form.dispose()


}

 

Function oldrandomIOPS {

   param (
        [string]$text,
        [string]$global:disk
    )

$data = $null 

# the format has to be just like below
# Test N#	 Drive	 Operation	 Access	 Blocks	 Run N#	 IOPS	 MB/sec	 Latency ms	 CPU %
# place the numbers in the csv as csv or space seperated values 
 # set path asap 
 Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Windows.Forms.DataVisualization

$mydownloads = (New-Object -ComObject Shell.Application).NameSpace('shell:Downloads').Self.Path
$myscriptloc = $PSScriptRoot
$mydir = "$mydownloads\CornersTestandGraph2.0\"
Set-Location -path  "$mydownloads\CornersTestandGraph2.0\"

# Get all PNG files in the directory (excluding "example.png")
$pngFiles = Get-ChildItem -Path $mydir -Filter "*.png" | Where-Object { $_.Name -ne "example.png" }

# Do something with the selected PNG files (e.g., process them or display their names)
If (!($pngFiles)) { 
$timecost.text = "Intake new Job..."

if (test-path -Path dat.old ) {del dat.old -force}
 
 if (test-path -Path output.txt) {
  
    if (test-path -Path $mydir\dat.csv) { Rename-Item -Path dat.csv -NewName dat.old -force; sleep(2) }
    Rename-Item -Path output.txt -NewName dat.csv -force ; sleep (3)
  }

  # Load the data from a CSV file
$data = Import-Csv -Path "$mydir\dat.csv"

Sleep(3)

  }


if (!($data)) { $data = Import-Csv -Path "$mydir\dat.csv" -ErrorAction SilentlyContinue -WarningAction SilentlyContinue; Sleep(3)}



 
 

# Filter the data to include only rows where the Operation column contains "Read"
$read_data = $data | Where-Object { $_.Operation -like "*Read*" }
sleep (3)

# Split the data into two sets based on the Access column
$read_random_access_data = $read_data | Where-Object { $_.Access -like "*Random*" }
#$read_sequential_access_data = $read_data | Where-Object { $_.Access -like "*Sequential*" }

#########test random read and sequential read data 
$read_random_access_data | ft
#$read_sequential_access_data | ft

# Combine the two sets of data and create a new property to identify the access type
$read_combined_ran = $read_random_access_data | Select-Object @{Name="Access";Expression={"Random"}},Blocks,IOPS
#$Read_combined_seq = $read_sequential_access_data | Select-Object @{Name="Access";Expression={"Sequential"}},Blocks,MB/sec

##### FILTER THE DATA FOR WRITE DATA 
# Filter the data to include only rows where the Operation column contains "Write"
 $write_data = $data | Where-Object { $_.Operation -like "*Write*" }

# Split the data into two sets based on the Access column
$random_write_access_data = $write_data | Where-Object { $_.Access -like "Random" }
#$sequential_write_access_data = $write_data | Where-Object { $_.Access -like "Sequential" }

# Combine the two sets of data and create a new property to identify the access type
$write_combined_ran = $random_write_access_data | Select-Object @{Name="Access";Expression={"Random"}},Blocks,IOPS
#$Write_combined_seq = $sequential_write_access_data | Select-Object @{Name="Access";Expression={"Sequential"}},Blocks,MB/sec

#### test random and sequentual writes 
#$write_combined_ran | ft
#$Write_combined_seq | ft
$random_write_access_data | ft
#$sequential_write_access_data | ft


#### FINISH FILTER FOR WRITE DATA 


Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Windows.Forms.DataVisualization
# Create the graph
$chart = New-Object System.Windows.Forms.DataVisualization.Charting.Chart
$chart.Width = 800
$chart.Height = 600

$chartArea = New-Object System.Windows.Forms.DataVisualization.Charting.ChartArea
$chart.ChartAreas.Add($chartArea)

$legend = New-Object System.Windows.Forms.DataVisualization.Charting.Legend
$legend.Docking = "bottom"
$chart.Legends.Add($legend)

$dataSeries1 = New-Object System.Windows.Forms.DataVisualization.Charting.Series
$dataSeries1.Name = "Random Read"
$dataSeries1.XValueType = [System.Windows.Forms.DataVisualization.Charting.ChartValueType]::String
$dataSeries1.YValueType = [System.Windows.Forms.DataVisualization.Charting.ChartValueType]::Double
$dataSeries1.ChartType = [System.Windows.Forms.DataVisualization.Charting.SeriesChartType]::Line
$dataSeries1.BorderWidth = 2
$dataSeries1.Color = [System.Drawing.Color]::Blue

 

$dataSeries11 = New-Object System.Windows.Forms.DataVisualization.Charting.Series
$dataSeries11.Name = "Random Write"
$dataSeries11.XValueType = [System.Windows.Forms.DataVisualization.Charting.ChartValueType]::String
$dataSeries11.YValueType = [System.Windows.Forms.DataVisualization.Charting.ChartValueType]::Double
$dataSeries11.ChartType = [System.Windows.Forms.DataVisualization.Charting.SeriesChartType]::Line
$dataSeries11.BorderWidth = 2
$dataSeries11.Color = [System.Drawing.Color]::Green

 

foreach ($item in $read_combined_ran) {
    $blocks= $item."blocks"
    $access = $item.Access
    #$mb_sec = $item."MB/sec"
    $iops = $item.IOPS
    
    if ($access -eq "Random") {
        $dataSeries1.Points.AddXY($Blocks,$iops)
    } 
}
 
 
 
foreach ($item in $write_combined_ran) {
    $access = $item.Access
   # $mb_sec = $item."MB/sec"
    $iops = $item.IOPS
    $blocks = $item."Blocks"

    if ($access -eq "Random") {
        $dataSeries11.Points.AddXY($Blocks, $iops)
    }
        
   
}

 

# Create the first Y-axis
$yAxis1 = $chart.ChartAreas[0].AxisY
$yAxis1.Title = "IOPS"
$yAxis1.MajorGrid.Enabled = $false
$yAxis1.LabelStyle.Format = "0"
$yAxis1.Maximum = $maxYValue


$ChartTitle = New-Object System.Windows.Forms.DataVisualization.Charting.Title
$ChartTitle.Text = 'Sequential =Mb/Sec (yellow,Purple) / IO = IOPS count (Green,BLue)'
$Font = New-Object System.Drawing.Font @('Microsoft Sans Serif','9', [System.Drawing.FontStyle]::Bold)
$ChartTitle.Font =$Font
$Chart.Titles.Add($ChartTitle)

$chart.Series.Add($dataSeries1)
 

$chart.Series.Add($dataSeries11)
 
$chart.SaveImage("$mydir\randomIOPS.png", [System.Drawing.Imaging.ImageFormat]::Png)
#$combined_data | ConvertTo-Json | Out-File "$mydir\dataRandomIOPS.json" -Append
$read_combined_ran | ConvertTo-Json | Out-File "$mydir\randomIOPS.json" -Append
#$Read_combined_seq | ConvertTo-Json | Out-File "$mydir\randomIOPS.json" -Append
$write_combined_ran | ConvertTo-Json | Out-File "$mydir\randomIOPS.json" -Append
#$Write_combined_seq | ConvertTo-Json | Out-File "$mydir\randomIOPS.json" -Append
# Calculate the maximum Y-value by finding the largest value among all datasets
$maxYValue = ($maxIOPS_read_ran, $maxIOPS_read_seq, $maxIOPS_write_ran, $maxIOPS_write_seq) | Measure-Object -Maximum | Select-Object -ExpandProperty Maximum

## Rule For Sequential IO - THROUGHPUT Don’t worry about the IO- Only the throughput matters
### Rule	For Random IO- Only IOPS matters- don’t worry about throughput 

$chartForm = New-Object System.Windows.Forms.Form
$chartForm.SuspendLayout()
$chart.Dock = [System.Windows.Forms.DockStyle]::Fill
$chartForm.Controls.Add($chart)
$chartForm.ResumeLayout()

# Show the form
$chartForm.ShowDialog()
 

# Set the PictureBox's Image property to the newly generated chart image
$pictureBoxImage.Image = [System.Drawing.Image]::FromFile("$mydir\randomIOPS.png")

 



}




function SecThroughPut {

  param (
        [string]$text,
        [string]$global:disk
    )



$data = $null 

# the format has to be just like below
# Test N#	 Drive	 Operation	 Access	 Blocks	 Run N#	 IOPS	 MB/sec	 Latency ms	 CPU %
# place the numbers in the csv as csv or space seperated values 
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Windows.Forms.DataVisualization
 Add-Type -AssemblyName System.Drawing

 

$mydownloads = (New-Object -ComObject Shell.Application).NameSpace('shell:Downloads').Self.Path
$myscriptloc = $PSScriptRoot
$mydir = "$mydownloads\CornersTestandGraph2.0\"
Set-Location -path  "$mydownloads\CornersTestandGraph2.0\"

# Get all PNG files in the directory (excluding "example.png")
$pngFiles = Get-ChildItem -Path $mydir -Filter "*.png" | Where-Object { $_.Name -ne "example.png" }

# Do something with the selected PNG files (e.g., process them or display their names)
If (!($pngFiles)) { 
$timecost.text = "Intake new Job..."

if (test-path -Path dat.old ) {del dat.old -force}
 
 if (test-path -Path output.txt) {
  
    if (test-path -Path $mydir\dat.csv) { Rename-Item -Path dat.csv -NewName dat.old -force; sleep(2) }
    Rename-Item -Path output.txt -NewName dat.csv -force ; sleep (3)
  }

  # Load the data from a CSV file
$data = Import-Csv -Path "$mydir\dat.csv"

Sleep(3)

  }


if (!($data))
{ $data = Import-Csv -Path "$mydir\dat.csv" -ErrorAction SilentlyContinue -WarningAction SilentlyContinue; Sleep(3)}



 
 

# Filter the data to include only rows where the Operation column contains "Read"
$read_data = $data | Where-Object { $_.Operation -like "*Read*" }
sleep (3)




# Split the data into two sets based on the Access column
#$read_random_access_data = $read_data | Where-Object { $_.Access -like "*Random*" }
$read_sequential_access_data = $read_data | Where-Object { $_.Access -like "*Sequential*" }

#########test random read and sequential read data 
$read_random_access_data | ft
$read_sequential_access_data | ft

# Combine the two sets of data and create a new property to identify the access type
#$read_combined_ran = $read_random_access_data | Select-Object @{Name="Access";Expression={"Random"}},Blocks,IOPS
$Read_combined_seq = $read_sequential_access_data | Select-Object @{Name="Access";Expression={"Sequential"}},Blocks,MB/sec

##### FILTER THE DATA FOR WRITE DATA 
# Filter the data to include only rows where the Operation column contains "Write"
 $write_data = $data | Where-Object { $_.Operation -like "*Write*" }

# Split the data into two sets based on the Access column
#$random_write_access_data = $write_data | Where-Object { $_.Access -like "Random" }
$sequential_write_access_data = $write_data | Where-Object { $_.Access -like "Sequential" }

# Combine the two sets of data and create a new property to identify the access type
#$write_combined_ran = $random_write_access_data | Select-Object @{Name="Access";Expression={"Random"}},Blocks,IOPS
$Write_combined_seq = $sequential_write_access_data | Select-Object @{Name="Access";Expression={"Sequential"}},Blocks,MB/sec

# Find the largest value for MB/sec in each dataset
 

# Find the largest value for MB/sec in each dataset
$maxMBSec_read_seq = $Read_combined_seq | ForEach-Object { [double]$_.("MB/sec") } | Measure-Object -Maximum | Select-Object -ExpandProperty Maximum
$maxMBSec_write_seq = $Write_combined_seq | ForEach-Object { [double]$_.("MB/sec") } | Measure-Object -Maximum | Select-Object -ExpandProperty Maximum


#### test random and sequentual writes 
#$write_combined_ran | ft
#$Write_combined_seq | ft
#$random_write_access_data | ft
$sequential_write_access_data | ft


#### FINISH FILTER FOR WRITE DATA 
$maxY2Value = ($maxMBSec_read_seq, $maxMBSec_write_seq) | Measure-Object -Maximum | Select-Object -ExpandProperty Maximum


# Create the graph
$chart = New-Object System.Windows.Forms.DataVisualization.Charting.Chart
$chart.Width = 800
$chart.Height = 600

$chartArea = New-Object System.Windows.Forms.DataVisualization.Charting.ChartArea
$chart.ChartAreas.Add($chartArea)

$legend = New-Object System.Windows.Forms.DataVisualization.Charting.Legend
$legend.Docking = "bottom"
$chart.Legends.Add($legend)

$dataSeries2 = New-Object System.Windows.Forms.DataVisualization.Charting.Series
$dataSeries2.Name = "Sequential Read"
$dataSeries2.XValueType = [System.Windows.Forms.DataVisualization.Charting.ChartValueType]::String
$dataSeries2.YValueType = [System.Windows.Forms.DataVisualization.Charting.ChartValueType]::Double
$dataSeries2.ChartType = [System.Windows.Forms.DataVisualization.Charting.SeriesChartType]::Line
$dataSeries2.BorderWidth = 2
$dataSeries2.Color = [System.Drawing.Color]::Yellow

$dataSeries21 = New-Object System.Windows.Forms.DataVisualization.Charting.Series
$dataSeries21.Name = "Sequential Write"
$dataSeries21.XValueType = [System.Windows.Forms.DataVisualization.Charting.ChartValueType]::String
$dataSeries21.YValueType = [System.Windows.Forms.DataVisualization.Charting.ChartValueType]::Double
$dataSeries21.ChartType = [System.Windows.Forms.DataVisualization.Charting.SeriesChartType]::Line
$dataSeries21.BorderWidth = 2
$dataSeries21.Color = [System.Drawing.Color]::Magenta
 


# Create the Y-axis
$yAxis = $chart.ChartAreas[0].AxisY
$yAxis.Title = "MB/sec"
$yAxis.MajorGrid.Enabled = $false
$yAxis.LabelStyle.Format = "F2"  # Set format specifier to display up to two decimal places
$yAxis.Maximum = $maxY2Value

$ChartTitle = New-Object System.Windows.Forms.DataVisualization.Charting.Title
$ChartTitle.Text = 'Sequential =Mb/Sec (yellow,Magenta) / IO = IOPS count (Green,BLue)'
$Font = New-Object System.Drawing.Font @('Microsoft Sans Serif','12', [System.Drawing.FontStyle]::Bold)
$ChartTitle.Font =$Font
$Chart.Titles.Add($ChartTitle)

foreach ($item in $Read_combined_seq) {
    $access = $item.Access
    $mb_sec = $item."MB/sec"
    $blocks = $item.Blocks

    if ($access -like "Sequential") {
        $dataSeries2.Points.AddXY($blocks, $mb_sec)
    } 
}

foreach ($item in $Write_combined_seq) {
    $access = $item.Access
    $mb_sec = $item."MB/sec"
    $blocks = $item.Blocks

    if ($access -like "Sequential") {
        $dataSeries21.Points.AddXY($blocks, $mb_sec)
    }
}

$chart.Series.Add($dataSeries2)
$chart.Series.Add($dataSeries21)
 
$chart.SaveImage("$mydir\SeqThroughPut.png", [System.Drawing.Imaging.ImageFormat]::Png)
$Read_combined_seq | ConvertTo-Json | Out-File "$mydir\SeqThroughPut.json" -Append
$Write_combined_seq | ConvertTo-Json | Out-File "$mydir\SeqThroughPut.json" -Append

# Show the form
$chartForm = New-Object System.Windows.Forms.Form
$chartForm.SuspendLayout()
$chart.Dock = [System.Windows.Forms.DockStyle]::Fill
$chartForm.Controls.Add($chart)
$chartForm.ResumeLayout()
$chartForm.ShowDialog()
 

# Show the form
$chartForm.ShowDialog()
 

# Set the PictureBox's Image property to the newly generated chart image
$pictureBoxImage.Image = [System.Drawing.Image]::FromFile("$mydir\SeqThroughPut.png")

 


}  


Function randomIOPS
{
 

$data = $null 

# the format has to be just like below
# Test N#	 Drive	 Operation	 Access	 Blocks	 Run N#	 IOPS	 MB/sec	 Latency ms	 CPU %
# place the numbers in the csv as csv or space seperated values 
 # set path asap 
 Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Windows.Forms.DataVisualization

$mydownloads = (New-Object -ComObject Shell.Application).NameSpace('shell:Downloads').Self.Path
$myscriptloc = $PSScriptRoot
$mydir = "$mydownloads\CornersTestandGraph2.0\"
Set-Location -path  "$mydownloads\CornersTestandGraph2.0\"

# Get all PNG files in the directory (excluding "example.png")
$pngFiles = Get-ChildItem -Path $mydir -Filter "*.png" | Where-Object { $_.Name -ne "example.png" }

# Do something with the selected PNG files (e.g., process them or display their names)
If (!($pngFiles)) { 
#$timecost.text = "Intake new Job..."

if (test-path -Path dat.old ) {del dat.old -force}
 
 if (test-path -Path output.txt) {
  
    if (test-path -Path $mydir\dat.csv) { Rename-Item -Path dat.csv -NewName dat.old -force; sleep(2) }
    Rename-Item -Path output.txt -NewName dat.csv -force ; sleep (3)
  }

  # Load the data from a CSV file
$data = Import-Csv -Path "$mydir\dat.csv"

Sleep(3)

  }


if (!($data))
{ $data = Import-Csv -Path "$mydir\dat.csv" -ErrorAction SilentlyContinue -WarningAction SilentlyContinue; Sleep(3)}


 

# Filter the data to include only rows where the Operation column contains "Read"
$read_data = $data | Where-Object { $_.Operation -like "*Read*" }
sleep (3)

# Split the data into two sets based on the Access column
$read_random_access_data = $read_data | Where-Object { $_.Access -like "*Random*" }
#$read_sequential_access_data = $read_data | Where-Object { $_.Access -like "*Sequential*" }

#########test random read and sequential read data 
$read_random_access_data | ft
#$read_sequential_access_data | ft

# Combine the two sets of data and create a new property to identify the access type
$read_combined_ran = $read_random_access_data | Select-Object @{Name="Access";Expression={"Random"}},Blocks,IOPS
#$Read_combined_seq = $read_sequential_access_data | Select-Object @{Name="Access";Expression={"Sequential"}},Blocks,MB/sec

##### FILTER THE DATA FOR WRITE DATA 
# Filter the data to include only rows where the Operation column contains "Write"
 $write_data = $data | Where-Object { $_.Operation -like "*Write*" }

# Split the data into two sets based on the Access column
$random_write_access_data = $write_data | Where-Object { $_.Access -like "Random" }
#$sequential_write_access_data = $write_data | Where-Object { $_.Access -like "Sequential" }

# Combine the two sets of data and create a new property to identify the access type
$write_combined_ran = $random_write_access_data | Select-Object @{Name="Access";Expression={"Random"}},Blocks,IOPS
#$Write_combined_seq = $sequential_write_access_data | Select-Object @{Name="Access";Expression={"Sequential"}},Blocks,MB/sec

#### test random and sequentual writes 
#$write_combined_ran | ft
#$Write_combined_seq | ft
$random_write_access_data | ft
#$sequential_write_access_data | ft



# Calculate the maximum IOPS value for each access type
$maxIOPS_read_ran = $read_combined_ran | Measure-Object -Property IOPS -Maximum | Select-Object -ExpandProperty Maximum
$maxIOPS_write_ran = $write_combined_ran | Measure-Object -Property IOPS -Maximum | Select-Object -ExpandProperty Maximum

 $maxYValue = ($maxIOPS_read_ran, $maxIOPS_read_seq, $maxIOPS_write_ran, $maxIOPS_write_seq) | Measure-Object -Maximum | Select-Object -ExpandProperty Maximum


#### FINISH FILTER FOR WRITE DATA 


Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Windows.Forms.DataVisualization
# Create the graph
$chart = New-Object System.Windows.Forms.DataVisualization.Charting.Chart
$chart.Width = 800
$chart.Height = 600

$chartArea = New-Object System.Windows.Forms.DataVisualization.Charting.ChartArea
$chart.ChartAreas.Add($chartArea)

$legend = New-Object System.Windows.Forms.DataVisualization.Charting.Legend
$legend.Docking = "bottom"
$chart.Legends.Add($legend)

$dataSeries1 = New-Object System.Windows.Forms.DataVisualization.Charting.Series
$dataSeries1.Name = "Random Read"
$dataSeries1.XValueType = [System.Windows.Forms.DataVisualization.Charting.ChartValueType]::String
$dataSeries1.YValueType = [System.Windows.Forms.DataVisualization.Charting.ChartValueType]::Double
$dataSeries1.ChartType = [System.Windows.Forms.DataVisualization.Charting.SeriesChartType]::Line
$dataSeries1.BorderWidth = 2
$dataSeries1.Color = [System.Drawing.Color]::Blue

 

$dataSeries11 = New-Object System.Windows.Forms.DataVisualization.Charting.Series
$dataSeries11.Name = "Random Write"
$dataSeries11.XValueType = [System.Windows.Forms.DataVisualization.Charting.ChartValueType]::String
$dataSeries11.YValueType = [System.Windows.Forms.DataVisualization.Charting.ChartValueType]::Double
$dataSeries11.ChartType = [System.Windows.Forms.DataVisualization.Charting.SeriesChartType]::Line
$dataSeries11.BorderWidth = 2
$dataSeries11.Color = [System.Drawing.Color]::Green

 

foreach ($item in $read_combined_ran) {
    $blocks= $item."blocks"
    $access = $item.Access
    #$mb_sec = $item."MB/sec"
    $iops = $item.IOPS
    
    if ($access -eq "Random") {
        $dataSeries1.Points.AddXY($Blocks,$iops)
    } 
}
 
 
 
foreach ($item in $write_combined_ran) {
    $access = $item.Access
   # $mb_sec = $item."MB/sec"
    $iops = $item.IOPS
    $blocks = $item."Blocks"

    if ($access -eq "Random") {
        $dataSeries11.Points.AddXY($Blocks, $iops)
    }
        
   
}

 

# Create the first Y-axis
$yAxis1 = $chart.ChartAreas[0].AxisY
$yAxis1.Title = "IOPS"
$yAxis1.MajorGrid.Enabled = $false
$yAxis1.LabelStyle.Format = "0"
$yAxis1.Maximum = $maxYValue


$ChartTitle = New-Object System.Windows.Forms.DataVisualization.Charting.Title
$ChartTitle.Text = 'Sequential =Mb/Sec (yellow,Purple) / IO = IOPS count (Green,BLue)'
$Font = New-Object System.Drawing.Font @('Microsoft Sans Serif','9', [System.Drawing.FontStyle]::Bold)
$ChartTitle.Font =$Font
$Chart.Titles.Add($ChartTitle)

$chart.Series.Add($dataSeries1)
 

$chart.Series.Add($dataSeries11)
 
$chart.SaveImage("$mydir\randomIOPS.png", [System.Drawing.Imaging.ImageFormat]::Png)
#$combined_data | ConvertTo-Json | Out-File "$mydir\dataRandomIOPS.json" -Append
$read_combined_ran | ConvertTo-Json | Out-File "$mydir\randomIOPS.json" -Append
#$Read_combined_seq | ConvertTo-Json | Out-File "$mydir\randomIOPS.json" -Append
$write_combined_ran | ConvertTo-Json | Out-File "$mydir\randomIOPS.json" -Append
#$Write_combined_seq | ConvertTo-Json | Out-File "$mydir\randomIOPS.json" -Append
# Calculate the maximum Y-value by finding the largest value among all datasets


## Rule For Sequential IO - THROUGHPUT Don’t worry about the IO- Only the throughput matters
### Rule	For Random IO- Only IOPS matters- don’t worry about throughput 

$chartForm = New-Object System.Windows.Forms.Form
$chartForm.SuspendLayout()
$chart.Dock = [System.Windows.Forms.DockStyle]::Fill
$chartForm.Controls.Add($chart)
$chartForm.ResumeLayout()

# Show the form
$chartForm.ShowDialog()
 

# Set the PictureBox's Image property to the newly generated chart image
$pictureBoxImage.Image = [System.Drawing.Image]::FromFile("$mydir\randomIOPS.png")

 







}

 
### Testing Apps BELOW ONLY###############
 
 #10min 2 blocks 8 tests 8 and 16k
Function Singletest
{

# 8 tests 2 block sizes 8 and 64


 


# Drive performance Report Generator
# by Arnaud TORRES
# Microsoft provides script, macro, and other code examples for illustration only, without warranty either expressed or implied, including but not
# limited to the implied warranties of merchantability and/or fitness for a particular purpose. This script is provided 'as is' and Microsoft does not
# guarantee that the following script, macro, or code can be used in all situations.
# Script will stress your computer CPU and storage, be sure that no critical workload is running

# Clear screen
$loco= set-location -Path $PSScriptRoot






write-host "DRIVE PERFORMANCE REPORT GENERATOR" -foregroundcolor green
write-host "Script will stress your computer CPU and storage layer (including network if applicable !), be sure that no critical workload is running" -foregroundcolor yellow
write-host "Microsoft provides script, macro, and other code examples for illustration only, without warranty either expressed or implied, including but not limited to the implied warranties of merchantability and/or fitness for a particular purpose. This script is provided 'as is' and Microsoft does not guarantee that the following script, macro, or code can be used in all situations." -foregroundcolor yellow

"Test will use all free space on drive minus 2 GB !"
"If there are less than 4 GB free test will stop"

# Disk to test
$Global:Disk = Read-Host 'Which disk would you like to test ? (example : D:)'

# $global:disk = "D:"

# Add the headers to the output file
“Test N#, Drive, Operation, Access, Blocks, Run N#, IOPS, MB/sec, Latency ms, CPU %" >> ./output.txt


if ($global:disk.length -ne 2){"Wrong drive letter format used, please specify the drive as D:"
Exit}

if ($global:disk.substring(1,1) -ne ":"){"Wrong drive letter format used, please specify the drive as D:"
Exit}

$global:disk = $global:disk.ToUpper()

# Reset test counter
$counter = 0

# Use 1 thread / core
$Thread = "-t"+(Get-WmiObject win32_processor).NumberofCores

# Set time in seconds for each run
# 10-120s is fine
$Time = "-d60"

# Outstanding IOs
# Should be 2 times the number of disks in the RAID
# Between  8 and 16 is generally fine
$OutstandingIO = "-o16"

# Disk preparation
# Delete testfile.dat if it exists
# The test will use all free space -2GB

$IsDir = test-path -path "$global:disk\TestDiskSpd"
$isdir
if ($IsDir -like "False"){new-item -itemtype directory -path "$global:disk\TestDiskSpd\"}

# Just a little security, in case we are working on a compressed drive ...
compact /u /s $global:disk\TestDiskSpd\

$Cleaning = test-path -path "$global:disk\TestDiskSpd\testfile.dat"
if ($Cleaning -eq "True")
{"Removing current testfile.dat from drive"
remove-item $global:disk\TestDiskSpd\testfile.dat}

$global:disks = Get-WmiObject win32_logicaldisk
$LogicalDisk = $global:disks | where {$_.DeviceID -eq $global:disk}
$Freespace = $LogicalDisk.freespace
$FreespaceGB = [int]($Freespace / 1073741824)
if($FreespaceGB -gt 6){
$Capacity = 12
}
Else{
Write-host "Not enough free space ($freespaceGB), need at least 6GB"
Exit}
$CapacityParameter = "-c"+$Capacity+"G"
$CapacityO = $Capacity * 1073741824
if ($FreespaceGB -lt "4"){
"Not enough space on the Disk ! More than 4GB needed"
Exit}

Write-host " "
$Continue = Read-Host "You are about to test $global:disk which has $FreespaceGB GB free, do you wan't to continue ? (Y/N) "
if ($continue -ne "y" -or $continue -ne "Y"){"Test Cancelled !!"
Exit}



"Initialization can take some time, we are generating a $Capacity GB file..."

"  "
# Initialize output file
$date = get-date

$mypath = $MyInvocation.MyCommand.path
$mydir = split-path $mypath -Parent

Set-Location -Path $mydir



# Add the tested disk and the date in the output file
	$servicetag= (get-wmiobject win32_systemEnclosure).SerialNumber
$dinfo = (get-volume).Size														   
						  

"Disk $global:disk, $date, $servicetag, $dinfo" >> ./ToSupport.txt


# Number of tests
# Multiply the number of loops to change this value
# By default there are : (4 blocks sizes) X (2 for read 100% and write 100%) X (2 for Sequential and Random) X (4 Runs of each)

$NumberOfTests = 8
 
write-host "TEST RESULTS (also logged in .\output.txt)" -foregroundcolor yellow

# Begin Tests loops
# We will run the tests with 4K, 8K, 64K and 512K blocks

 
							   
							

do {
    (8, 64) | ForEach-Object {
        $BlockParameter = ("-b" + $_ + "K")
        $Blocks = ("Blocks " + $_ + "K")

        # We will do Read tests and Write tests
        (0, 100) | ForEach-Object {
            if ($_ -eq 0) { $IO = "Read" }
            if ($_ -eq 100) { $IO = "Write" }
            $WriteParameter = "-w" + $_

            # We will do random and sequential IO tests
            ("r", "si") | ForEach-Object {
                if ($_ -eq "r") { $type = "Random" }
                if ($_ -eq "si") { $type = "Sequential" }
                $AccessParameter = "-" + $_

                # Each run will be done 4 times
                (1..1) | ForEach-Object {
                    # The test itself (finally!!)
                    $result = .\diskspd.exe $CapacityPArameter $Time $AccessParameter $WriteParameter $Thread $OutstandingIO $BlockParameter -h -L $global:disk\TestDiskSpd\testfile.dat

                    # Now we will break the very verbose output of DiskSpd in a single line with the most important values
                    foreach ($line in $result) { if ($line -like "*total:*") { $total = $line; break } }
                    foreach ($line in $result) { if ($line -like "*avg.*") { $avg = $line; break } }
                    $mbps = $total.Split("|")[2].Trim()
                    $iops = $total.Split("|")[3].Trim()
                    $latency = $total.Split("|")[4].Trim()
                    $cpu = $avg.Split("|")[1].Trim()
                    $counter = $counter + 1

                    # A progress bar, for the fun
                    Write-Progress -Activity ".\diskspd.exe $CapacityPArameter $Time $AccessParameter $WriteParameter $Thread $OutstandingIO $BlockParameter -h -L $global:disk\TestDiskSpd\testfile.dat" -status "Test in progress" -percentComplete ($counter / ($NumberofTests) * 100)    

                    # Remove comment to check command line ".\diskspd.exe $CapacityPArameter $Time $AccessParameter $WriteParameter $Thread -$OutstandingIO $BlockParameter -h -L $global:disk\TestDiskSpd\testfile.dat"
                 

                        # Remove comment to check command line ".\diskspd.exe $CapacityPArameter $Time $AccessParameter $WriteParameter $Thread -$OutstandingIO $BlockParameter -h -L $global:disk\TestDiskSpd\testfile.dat"
                    # We output the values to the text file
                $testcost.text =    "Test $Counter,$global:disk,$IO,$type,$Blocks,Run $_,$iops,$mbps,$latency,$cpu"  
                 
                                             
               
               $output = "Test $Counter,$global:disk,$IO,$type,$Blocks,Run $_,$iops,$mbps,$latency,$cpu"
                  Write-Output $output
                    Add-Content -Path ./output.txt -Value $output


                    # We output a verbose format on screen
               write-host "Test $Counter, $global:disk, $IO, $type, $Blocks, Run $_, $iops iops, $mbps MB/sec, $latency ms, $cpu CPU"
                  

                }

            }

        }

    }

    # Calculate the percentage completed based on the total number of tests and the current counter value
    $percentComplete = [Math]::Round(($counter / $NumberOfTests ) * 100)

} while ($counter -lt $NumberOfTests)
Write-Progress -Activity ".\diskspd.exe $CapacityPArameter $Time $AccessParameter $WriteParameter $Thread $OutstandingIO $BlockParameter -h -L $global:disk\TestDiskSpd\testfile.dat" -status "Ready" -Completed  
Write-host " Testing is complete. You may have to restart the application and chose the Open Graph Button."   




 



}


#53 minutes##
 
 ## 12 capacity 60 seconds per test-num of test 16
function corner1  {

        param (
       [string]$global:disk
    )
# Drive performance Report Generator
# by Arnaud TORRES
# Microsoft provides script, macro, and other code examples for illustration only, without warranty either expressed or implied, including but not
# limited to the implied warranties of merchantability and/or fitness for a particular purpose. This script is provided 'as is' and Microsoft does not
# guarantee that the following script, macro, or code can be used in all situations.
# Script will stress your computer CPU and storage, be sure that no critical workload is running
$global:disk = $Global:Disk
# Clear screen
$loco= set-location -Path $PSScriptRoot
$mypath = $MyInvocation.MyCommand.path
$mydir = split-path $mypath -Parent

Set-Location -Path $mydir
$loco= set-location -Path $PSScriptRoot
 
 


write-host "DRIVE PERFORMANCE REPORT GENERATOR" -foregroundcolor green
write-host "Script will stress your computer CPU and storage layer (including network if applicable !), be sure that no critical workload is running" -foregroundcolor yellow
write-host "Microsoft provides script, macro, and other code examples for illustration only, without warranty either expressed or implied, including but not limited to the implied warranties of merchantability and/or fitness for a particular purpose. This script is provided 'as is' and Microsoft does not guarantee that the following script, macro, or code can be used in all situations." -foregroundcolor yellow

 

 
# $global:disk = "D:"

if ($global:disk.length -ne 2){"Wrong drive letter format used, please specify the drive as D:"
Exit}

if ($global:disk.substring(1,1) -ne ":"){"Wrong drive letter format used, please specify the drive as D:"
Exit}

$global:disk = $global:disk.ToUpper()

# Reset test counter
$counter = 0

# Use 1 thread / core
$Thread = "-t"+(Get-WmiObject win32_processor).NumberofCores

# Set time in seconds for each run
# 10-120s is fine
$Time = "-d60"

# Outstanding IOs
# Should be 2 times the number of disks in the RAID
# Between  8 and 16 is generally fine
$OutstandingIO = "-o16"

# Disk preparation
# Delete testfile.dat if it exists
# The test will use all free space -2GB

$IsDir = test-path -path "$global:disk\TestDiskSpd"
$isdir
if ($IsDir -like "False"){new-item -itemtype directory -path "$global:disk\TestDiskSpd\"}

# Just a little security, in case we are working on a compressed drive ...
compact /u /s $global:disk\TestDiskSpd\

$Cleaning = test-path -path "$global:disk\TestDiskSpd\testfile.dat"
if ($Cleaning -eq "True")
{"Removing current testfile.dat from drive"
remove-item $global:disk\TestDiskSpd\testfile.dat}

$global:disks = Get-WmiObject win32_logicaldisk
$LogicalDisk = $global:disks | where {$_.DeviceID -eq $global:disk}
$Freespace = $LogicalDisk.freespace
$FreespaceGB = [int]($Freespace / 1073741824)
if($FreespaceGB -gt 6){
$Capacity = 12
}
Else{
Write-host "Not enough free space ($freespaceGB), need at least 6GB"
Exit}
$CapacityParameter = "-c"+$Capacity+"G"
$CapacityO = $Capacity * 1073741824
if ($FreespaceGB -lt "4"){
"Not enough space on the Disk ! More than 4GB needed"
Exit}

Write-host " "
$Continue = Read-Host "You are about to test $global:disk which has $FreespaceGB GB free, do you wan't to continue ? (Y/N) "
if ($continue -ne "y" -or $continue -ne "Y"){"Test Cancelled !!"
Exit}



"Initialization can take some time, we are generating a $Capacity GB file..."

"  "
# Initialize outpout file
$date = get-date

# Add the tested disk and the date in the output file
$servicetag= (get-wmiobject win32_systemEnclosure).SerialNumber
$dinfo = (get-volume).Size														   

 

# Get the current date and time
$date = Get-Date

# Convert to regular time format with AM/PM
$regularTime = $date.ToString("hh-mm-ss tt")

# Content to write to the file
$content = "Disk $global:disk, $date, $servicetag, $dinfo"  

# Specify the file path and name using the variable
$filePath = "$mydir\$regularTime.txt"

# Create the file and write the content
$content | Out-File -FilePath $filePath


# Add the headers to the output file - stops graph from working 
“Test N#, Drive, Operation, Access, Blocks, Run N#, IOPS, MB/sec, Latency ms, CPU %" >> ./output.txt

# Number of tests
# Multiply the number of loops to change this value
# By default there are : (4 blocks sizes) X (2 for read 100% and write 100%) X (2 for Sequential and Random) X (4 Runs of each)

$NumberOfTests = 16


write-host "TEST RESULTS (also logged in .\output.txt)" -foregroundcolor yellow

# Begin Tests loops
# We will run the tests with 4K, 8K, 64K and 512K blocks

 
							   
							

do {
    (4, 8, 64, 512) | ForEach-Object {
        $BlockParameter = ("-b" + $_ + "K")
        $Blocks = ("Blocks " + $_ + "K")

        # We will do Read tests and Write tests
        (0, 100) | ForEach-Object {
            if ($_ -eq 0) { $IO = "Read" }
            if ($_ -eq 100) { $IO = "Write" }
            $WriteParameter = "-w" + $_

            # We will do random and sequential IO tests
            ("r", "si") | ForEach-Object {
                if ($_ -eq "r") { $type = "Random" }
                if ($_ -eq "si") { $type = "Sequential" }
                $AccessParameter = "-" + $_

                # Each run will be done 4 times
                (1..1) | ForEach-Object {
                    # The test itself (finally!!)
                    $result = .\diskspd.exe $CapacityPArameter $Time $AccessParameter $WriteParameter $Thread $OutstandingIO $BlockParameter -h -L $global:disk\TestDiskSpd\testfile.dat

                    # Now we will break the very verbose output of DiskSpd in a single line with the most important values
                    foreach ($line in $result) { if ($line -like "*total:*") { $total = $line; break } }
                    foreach ($line in $result) { if ($line -like "*avg.*") { $avg = $line; break } }
                    $mbps = $total.Split("|")[2].Trim()
                    $iops = $total.Split("|")[3].Trim()
                    $latency = $total.Split("|")[4].Trim()
                    $cpu = $avg.Split("|")[1].Trim()
                    $counter = $counter + 1

                    # A progress bar, for the fun
                    Write-Progress -Activity ".\diskspd.exe $CapacityPArameter $Time $AccessParameter $WriteParameter $Thread $OutstandingIO $BlockParameter -h -L $global:disk\TestDiskSpd\testfile.dat" -status "Test in progress" -percentComplete ($counter / ($NumberofTests) * 100)    

                    # Remove comment to check command line ".\diskspd.exe $CapacityPArameter $Time $AccessParameter $WriteParameter $Thread -$OutstandingIO $BlockParameter -h -L $global:disk\TestDiskSpd\testfile.dat"
                    # We output the values to the text file
					$testcost.text =    "Test $Counter,$global:disk,$IO,$type,$Blocks,Run $_,$iops,$mbps,$latency,$cpu"  
                
               

               $output = "Test $Counter,$global:disk,$IO,$type,$Blocks,Run $_,$iops,$mbps,$latency,$cpu"
                  Write-Output $output
                    Add-Content -Path ./output.txt -Value $output


                    # We output a verbose format on screen
               write-host "Test $Counter, $global:disk, $IO, $type, $Blocks, Run $_, $iops iops, $mbps MB/sec, $latency ms, $cpu CPU"

                }

            }

        }

    }

    # Calculate the percentage completed based on the total number of tests and the current counter value
    $percentComplete = [Math]::Round(($counter / $NumberOfTests ) * 100)

} while ($counter -lt $NumberOfTests)

Write-Progress -Activity ".\diskspd.exe $CapacityPArameter $Time $AccessParameter $WriteParameter $Thread $OutstandingIO $BlockParameter -h -L $global:disk\TestDiskSpd\testfile.dat" -status "Ready" -Completed  
Write-host " Testing is complete. You may have to restart the application and chose the Open Graph Button."

}


#morethen 40 min 
 
 # 6 capacity and 30 seconds per test 
Function actualcorner {
        param (
       [string]$global:disk
    )

$global:disk = $global:Disk
Write-host " $global:disk is $Global:Disk is working as designed"
# Drive performance Report Generator
# by Arnaud TORRES
# Microsoft provides script, macro, and other code examples for illustration only, without warranty either expressed or implied, including but not
# limited to the implied warranties of merchantability and/or fitness for a particular purpose. This script is provided 'as is' and Microsoft does not
# guarantee that the following script, macro, or code can be used in all situations.
# Script will stress your computer CPU and storage, be sure that no critical workload is running

# Clear screen
$loco= set-location -Path $PSScriptRoot


 
 
write-host "DRIVE PERFORMANCE REPORT GENERATOR" -foregroundcolor green
write-host "Script will stress your computer CPU and storage layer (including network if applicable !), be sure that no critical workload is running" -foregroundcolor yellow
write-host "Microsoft provides script, macro, and other code examples for illustration only, without warranty either expressed or implied, including but not limited to the implied warranties of merchantability and/or fitness for a particular purpose. This script is provided 'as is' and Microsoft does not guarantee that the following script, macro, or code can be used in all situations." -foregroundcolor yellow
 
Write-host "Test will use all free space on drive minus 2 GB !"
Write-host "If there are less than 4 GB free test will stop"

# Disk to test
Write-host " Entered Subroutine test module for disk: $global:disk"

 
#$Global:Disk = Read-Host 'Which disk would you like to test ? (example : D:)'

if ($global:disk.length -ne 2){"Wrong drive letter format used, please specify the drive as D:"
Exit}

if ($global:disk.substring(1,1) -ne ":"){"Wrong drive letter format used, please specify the drive as D:"
Exit}

$global:disk = $global:disk.ToUpper()

# Reset test counter
$counter = 0

# Use 1 thread / core
$Thread = "-t"+(Get-WmiObject win32_processor).NumberofCores

# Set time in seconds for each run
# 10-120s is fine
$Time = "-d30"

# Outstanding IOs
# Should be 2 times the number of disks in the RAID
# Between  8 and 16 is generally fine
$OutstandingIO = "-o16"

# Disk preparation
# Delete testfile.dat if it exists
# The test will use all free space -2GB

$IsDir = test-path -path "$global:disk\TestDiskSpd"
$isdir
if ($IsDir -like "False"){new-item -itemtype directory -path "$global:disk\TestDiskSpd\"}

# Just a little security, in case we are working on a compressed drive ...
compact /u /s $global:disk\TestDiskSpd\

$Cleaning = test-path -path "$global:disk\TestDiskSpd\testfile.dat"
if ($Cleaning -eq "True")
{"Removing current testfile.dat from drive"
remove-item $global:disk\TestDiskSpd\testfile.dat}

$global:disks = Get-WmiObject win32_logicaldisk
$LogicalDisk = $global:disks | where {$_.DeviceID -eq $global:disk}
$Freespace = $LogicalDisk.freespace
$FreespaceGB = [int]($Freespace / 1073741824)
if($FreespaceGB -gt 6){
$Capacity = 6
}
Else{
Write-host "Not enought free space ($freespaceGB), need at least 6GB"
Exit}
$CapacityParameter = "-c"+$Capacity+"G"
$CapacityO = $Capacity * 1073741824
if ($FreespaceGB -lt "4"){
"Not enough space on the Disk ! More than 4GB needed"
Exit}

Write-host " "
$Continue = Read-Host "You are about to test $global:disk which has $FreespaceGB GB free, do you wan't to continue ? (Y/N) "
if ($continue -ne "y" -or $continue -ne "Y"){"Test Cancelled !!"
Exit}



"Initialization can take some time, we are generating a $Capacity GB file..."

"  "
# Initialize outpout file
$date = get-date

# Add the tested disk and the date in the output file
															   
$servicetag= (get-wmiobject win32_systemEnclosure).SerialNumber
$dinfo = (get-volume).Size						  

"Disk $global:disk, $date, $servicetag, $dinfo" >> ./support.txt

# Add the headers to the output file breaks automation
"Test N#, Drive, Operation, Access, Blocks, Run N#, IOPS, MB/sec, Latency ms, CPU %" >> ./output.txt

# Number of tests
# Multiply the number of loops to change this value
# By default there are : (4 blocks sizes) X (2 for read 100% and write 100%) X (2 for Sequential and Random) X (4 Runs of each)

$NumberOfTests = 16

"  "
write-host "TEST RESULTS (also logged in .\output.txt)" -foregroundcolor yellow

# Begin Tests loops
# We will run the tests with 4K, 8K, 64K and 512K blocks

 

do {
    (4, 8, 64, 512) | ForEach-Object {
        $BlockParameter = ("-b" + $_ + "K")
        $Blocks = ("Blocks " + $_ + "K")

        # We will do Read tests and Write tests
        (0, 100) | ForEach-Object {
            if ($_ -eq 0) { $IO = "Read" }
            if ($_ -eq 100) { $IO = "Write" }
            $WriteParameter = "-w" + $_

            # We will do random and sequential IO tests
            ("r", "si") | ForEach-Object {
                if ($_ -eq "r") { $type = "Random" }
                if ($_ -eq "si") { $type = "Sequential" }
                $AccessParameter = "-" + $_

                # Each run will be done 4 times
                (1..1) | ForEach-Object {
                    # The test itself (finally!!)
                    $result = .\diskspd.exe $CapacityPArameter $Time $AccessParameter $WriteParameter $Thread $OutstandingIO $BlockParameter -h -L $global:disk\TestDiskSpd\testfile.dat

                    # Now we will break the very verbose output of DiskSpd in a single line with the most important values
                    foreach ($line in $result) { if ($line -like "*total:*") { $total = $line; break } }
                    foreach ($line in $result) { if ($line -like "*avg.*") { $avg = $line; break } }
                    $mbps = $total.Split("|")[2].Trim()
                    $iops = $total.Split("|")[3].Trim()
                    $latency = $total.Split("|")[4].Trim()
                    $cpu = $avg.Split("|")[1].Trim()
                    $counter = $counter + 1

                    # A progress bar, for the fun
                    Write-Progress -Activity ".\diskspd.exe $CapacityPArameter $Time $AccessParameter $WriteParameter $Thread $OutstandingIO $BlockParameter -h -L $global:disk\TestDiskSpd\testfile.dat" -status "Test in progress" -percentComplete ($counter / ($NumberofTests) * 100)    

                    # Remove comment to check command line ".\diskspd.exe $CapacityPArameter $Time $AccessParameter $WriteParameter $Thread -$OutstandingIO $BlockParameter -h -L $global:disk\TestDiskSpd\testfile.dat"
                    # We output the values to the text file
                $testcost.text =    "Test $Counter,$global:disk,$IO,$type,$Blocks,Run $_,$iops,$mbps,$latency,$cpu"  
                
                   
               

               $output = "Test $Counter,$global:disk,$IO,$type,$Blocks,Run $_,$iops,$mbps,$latency,$cpu"
                  Write-Output $output
                    Add-Content -Path ./output.txt -Value $output


                    # We output a verbose format on screen
               write-host "Test $Counter, $global:disk, $IO, $type, $Blocks, Run $_, $iops iops, $mbps MB/sec, $latency ms, $cpu CPU"






                }

            }

        }

    }

    # Calculate the percentage completed based on the total number of tests and the current counter value
    $percentComplete = [Math]::Round(($counter / $NumberOfTests ) * 100)

} while ($counter -lt $NumberOfTests)

Write-Progress -Activity ".\diskspd.exe $CapacityPArameter $Time $AccessParameter $WriteParameter $Thread $OutstandingIO $BlockParameter -h -L $global:disk\TestDiskSpd\testfile.dat" -status "Ready" -Completed  
Write-host " Testing is complete. You may have to restart the application and chose the Open Graph Button."








}



$mydownloads = (New-Object -ComObject Shell.Application).NameSpace('shell:Downloads').Self.Path
$myscriptloc = $PSScriptRoot


Write-host "Welcome to 4 corners storage test baseline"

 
Set-Location  "$mydownloads\CornersTestandGraph2.0\"
 
Rename-Item -Path "diskspd.__e" -NewName "diskspd.exe"
#Rename-Item -Path "DskSpd4C.ps1.renameme" -NewName "DskSpd4C.ps1"

$Global:Disk = read-host "Choose storage C:\ClusterStorage\Volume1 or \\fileserver\share or S: without ending \"
 
Write-host " Spinning up Test engine.. Please wait.. "


###Below is form action 
######################################################################################################################


#corner1 
$global:disk
 

#region Main Form

$mydownloads = (New-Object -ComObject Shell.Application).NameSpace('shell:Downloads').Self.Path
$myscriptloc = $PSScriptRoot
set-loc $myscriptloc

$menuArray = "4Corner", "Long Full" ,"Singletest"

    
$tracearray = "Graphall", "randomIOPS", "SeqThroughPut"
$performarray = "Graphall", "randomIOPS", "SeqThroughPut"
$SupportArray = "Graphall", "randomIOPS", "SeqThroughPut"
$Form = New-Object System.Windows.Forms.Form
$Form.Width = 1600
$Form.Height = 2500
$Form.Text = ".\CornersTestandGraph2.0.ps1"
$form.AutoSizeMode = 'None'



#Oryx_Antelope
$Image = [system.drawing.image]::FromFile("$($PSScriptRoot)\r2.jpg")
$backgroundImage = $Image
$image.width = 1000
$image.height = 500
$form.Text = ”CornersTestandGraph2.0.ps1”
## DROPDOWN TO CHOOSE COURSE OF COMMANDS 
$form.AutoSize = $false
$form.BackgroundImage = $Image
$form.BackgroundImageLayout = "None"
 
 # None, Tile, Center, Stretch, Zoom
$form.Width = $Image.Width
$form.Height = $Image.Height + 1000
$Font = New-Object System.Drawing.Font("Times New Roman",11,[System.Drawing.FontStyle]::Regular)
 # Font styles are: Regular, Bold, Italic, Underline, Strikeout
$form.TransparencyKey = $backgroundImage.GetPixel(100, 100)
$form.Font = $Font

# Create the first dropdown
$DropDown1 = New-Object System.Windows.Forms.ComboBox
$DropDown1.Location = New-Object System.Drawing.Size(150, 39)
$DropDown1.Size = New-Object System.Drawing.Size(133, 19)
$Dropown1.TransparencyKey = $backgroundImage.GetPixel(82, 29)
$DropDown1.BackColor = $backgroundImage.GetPixel(82,29)         #(82, 29)               #(92,39)

# Create the second dropdown
$secondDropDown = New-Object System.Windows.Forms.ComboBox
$secondDropDown.Location = New-Object System.Drawing.Size(150, 79)
$secondDropDown.Size = New-Object System.Drawing.Size(146, 19)
$secondDropDown.TransparencyKey = $backgroundImage.GetPixel(82, 29)       #(83, 89)
$secondDropDown.BackColor = $backgroundImage.GetPixel(82,29)

$DropDown1.Items.AddRange($menuArray)

# Create the timecost label (moved outside the event handler)
$timecost = New-Object System.Windows.Forms.Label
$timecost.Location = New-Object System.Drawing.Size(330, 80)
$timecost.Size = New-Object System.Drawing.Size(500, 30)
$Font = New-Object System.Drawing.Font("Times New Roman", 14, [System.Drawing.FontStyle]::Bold)
$timecost.Font = $Font
$timecost.TransparencyKey = $backgroundImage.GetPixel(100, 500)
$timecost.BackColor = $backgroundImage.GetPixel(100, 400)
$Form.Controls.Add($timecost)

# Add event handler to first dropdown
$DropDown1.Add_SelectedIndexChanged({
    $selectedValue = $DropDown1.SelectedItem.ToString()
     
    $secondDropDown.Items.Clear()

    switch ($selectedValue) {
        '4Corner' {
            $secondDropDown.Items.AddRange($tracearray)
            $gettime = "20"
            $timecost.Text = "Test runs for at least $gettime Minutes"
        }
        'Long Full' {
            $secondDropDown.Items.AddRange($performarray)
            $gettime = "55"
            $timecost.Text = "Test runs for at least $gettime Minutes"
        }
        'Singletest' {
            $secondDropDown.Items.AddRange($SupportArray)
            $gettime = "38"
            $timecost.Text = "Test runs for at least $gettime Minutes"
        }
    }
    $secondDropDown.Enabled = $true




})

$Form.Controls.Add($DropDown1)
$Form.Controls.Add($secondDropDown)

$DropDownLabel = New-Object System.Windows.Forms.Label
$DropDownLabel.Location = New-Object System.Drawing.Size(1, 39)
$DropDownLabel.Size = New-Object System.Drawing.Size(115, 20)
$DropDownLabel.TransparencyKey = $backgroundImage.GetPixel(82, 89)     #(20,30)
$DropDownLabel.BackColor = $backgroundImage.GetPixel(82, 89)
$DropDownLabel.Text = "Type Test"
$Form.Controls.Add($DropDownLabel)

$secondLabel = New-Object System.Windows.Forms.Label
$secondLabel.Location = New-Object System.Drawing.Size(1, 80)
$secondLabel.Size = New-Object System.Drawing.Size(150, 20) 

$SecondLabel.TransparencyKey = $backgroundImage.GetPixel(82, 89)
$SecondLabel.BackColor = $backgroundImage.GetPixel(82, 89)
$secondLabel.Text = "Type of Report"
$Form.Controls.Add($secondLabel)
 

$Button = New-Object System.Windows.Forms.Button
$Button.Location = New-Object System.Drawing.Size(310, 29)
$Button.Size = New-Object System.Drawing.Size(240, 29)
$Button.Text = "Start Test Disk $global:disk"



$Button.Add_Click({
    # Handle the button click event
     
    $global:disktest1 = $DropDown1.SelectedItem.ToString()
    $global:disktest2 = $secondDropDown.SelectedItem.ToString()
   
  
   
   switch ($global:disktest1) {
        '4Corner' {
             write-host "Generating Graphics in Downloads CornersTestandGraph2.0"

             actualcorner $global:disk
            
             
        }
        'Long Full' {
           write-host "Generating Graphics in Downloads CornersTestandGraph2.0"
           corner1 $global:disk
           
        }
        'Singletest' {
           write-host "Generating Graphics in Downloads CornersTestandGraph2.0"
           Singletest $global:disk
           
        }
    }
    $secondDropDown.Enabled = $true


$pictureBoxLocation = New-Object System.Drawing.Point(5, 50) # PictureBox starts at the top-left corner
$pictureBoxSize = New-Object System.Drawing.Size($form.Width , ($form.Height - 50)) # Adjust the size as needed

# Create the PictureBox control to display another image
$pictureBoxImage = New-Object System.Windows.Forms.PictureBox
$pictureBoxImage.Location = $pictureBoxLocation
$pictureBoxImage.Size = $pictureBoxSize
$pictureBoxImage.SizeMode = 'Zoom'
$timecost.Text = "Select Options first"
$filename1 = "$mydownloads\CornersTestandGraph2.0\$($global:disktest2.png)"
  $imagePath =  $filename1 # Use .bmp extension since you mentioned it opens fine as BMP
        if (Test-Path $imagePath) {
            $image2 = [System.Drawing.Image]::FromFile($imagePath)
            $pictureBoxImage.Image = $image2
            }

 $Form.Controls.Add($pictureBoxImage)



  })
$Form.Controls.Add($Button)

# Import the requiYellow namespace for keyboard handling
Add-Type -TypeDefinition @'
    using System;
    using System.Windows.Forms;
    
    public class KeyboardHandler : IMessageFilter
    {
        private const int WM_KEYDOWN = 0x0100;
        private const int VK_ESCAPE = 0x1B;

        public bool PreFilterMessage(ref Message m)
        {
            if (m.Msg == WM_KEYDOWN && (int)m.WParam == VK_ESCAPE)
            {
                Application.return();
                return true;
            }
            return false;
        }
    }
'@

# Create an instance of the keyboard handler and add it as a message filter
$keyboardHandler = New-Object -TypeName KeyboardHandler
[System.Windows.Forms.Application]::AddMessageFilter($keyboardHandler)

$secondButton = New-Object System.Windows.Forms.Button
$secondButton.Location = New-Object System.Drawing.Size(600, 43)
#235 151
$secondButton.Size = New-Object System.Drawing.Size(160, 30)
$secondButton.Text = "Generate Graph"
 

   


  

 
$secondButton.Add_Click({ 
 
  $global:disktest2 = $secondDropDown.SelectedItem.ToString()
  $filename2 = "$mydownloads\CornersTestandGraph2.0\$($global:disktest2).png"
 $mydownloads = (New-Object -ComObject Shell.Application).NameSpace('shell:Downloads').Self.Path
$myscriptloc = $PSScriptRoot
Set-Location  "$mydownloads\CornersTestandGraph2.0\"
 
 $timecost.text = "Checking for work to do..."
 
 
   switch ($global:disktest2) {
        'Graphall' {
             write-host "Generating Graphics in Downloads CornersTestandGraph2.0"

            Graphall $global:disk
            
             
        }
        'SecThroughPut' {
           write-host "Generating Graphics in Downloads CornersTestandGraph2.0"
           SecThroughPut $global:disk
           
        }
        'randomIOPS' {
           write-host "Generating Graphics in Downloads CornersTestandGraph2.0"
           randomIOPS $global:disk
           
        }
    }

$timecost.text = "Processing Complete or graphs exist..."
 
 try{
        # ... (existing code)
        $filename2 = "$mydownloads\CornersTestandGraph2.0\$($global:disktest2).png"
        $imagePath =  $filename2 # Use .bmp extension since you mentioned it opens fine as BMP
        if (Test-Path $imagePath) {
            $image2 = [System.Drawing.Image]::FromFile($imagePath)
             
            $pictureBoxImage.Image = $image2
            $form.Resize
            $timecost.Text = "Graphs displayed from $psscriptroot"
           # ResizePictureBox
$pictureBoxImage = New-Object System.Windows.Forms.PictureBox
$pictureBoxImage.Location = $pictureBoxLocation
$pictureBoxImage.Size = $pictureBoxSize
$pictureBoxImage.SizeMode = 'Zoom'
$timecost.Text = "Select Options first"
$Form.Controls.Add($pictureBoxImage)




        } else {
            $timecost.Text = "Image file not found at $imagePath"
        }
    } catch {
        $timecost.Text = "Error loading or displaying the image: $_"
    }

   

})

 

$Form.Controls.Add($secondButton)



$thirdButton = New-Object System.Windows.Forms.Button
$thirdButton.Location = New-Object System.Drawing.Size(600, 5)

$thirdButton.Size = New-Object System.Drawing.Size(160, 25)
$thirdButton.Text = "Terminate and return"
$thirdButton.Add_Click({ closeall })
$Form.Controls.Add($thirdButton)

 



$DropDownLabel2 = New-Object System.Windows.Forms.Label
$DropDownLabel2.Location = New-Object System.Drawing.Size(1, 10)
$DropDownLabel2.Size = New-Object System.Drawing.Size(125, 20)
$DropDownLabel2.TransparencyKey = $backgroundImage.GetPixel(10, 10)
$DropDownLabel2.BackColor = $backgroundImage.GetPixel(21,15)
$Font = New-Object System.Drawing.Font("Times NewRoman", 11, [System.Drawing.FontStyle]::Bold)
$DropDownLabel2.font = $font
$DropDownLabel2.Text = "DiskSpd Testing"
$Form.Controls.Add($DropDownLabel2)
#########################################

 
#Create the PictureBox control
#$pictureBoxImage = New-Object System.Windows.Forms.PictureBox
#$pictureBoxImage.Size = New-Object System.Drawing.Size($Form.Width - 100, $Form.Height * 0.67)  # Adjust the size as needed
#$pictureBoxImage.SizeMode = 'Zoom'  # Set the PictureBoxSizeMode to 'Zoom' to fit the image within the control
#$pictureBox.Size = New-Object System.Drawing.location($Form.Width,$Form.Height - 600)

 


  # Calculate the size and position for the PictureBox to take up the remaining space
$pictureBoxLocation = New-Object System.Drawing.Point(5, 50) # PictureBox starts at the top-left corner
$pictureBoxSize = New-Object System.Drawing.Size($form.Width , ($form.Height - 50)) # Adjust the size as needed

# Create the PictureBox control to display another image
$pictureBoxImage = New-Object System.Windows.Forms.PictureBox
$pictureBoxImage.Location = $pictureBoxLocation
$pictureBoxImage.Size = $pictureBoxSize
$pictureBoxImage.SizeMode = 'Zoom'
$timecost.Text = "Select Options first"
$filename1 = "$mydownloads\CornersTestandGraph2.0\example.png"
  $imagePath =  $filename1 # Use .bmp extension since you mentioned it opens fine as BMP
        if (Test-Path $imagePath) {
            $image2 = [System.Drawing.Image]::FromFile($imagePath)
            $pictureBoxImage.Image = $image2
            }

 $Form.Controls.Add($pictureBoxImage)

# Create the timecost label (moved outside the event handler)
$testcost = New-Object System.Windows.Forms.Label
$testcost.Location = New-Object System.Drawing.Size(0, 140)
$testcost.Size = New-Object System.Drawing.Size(750, 30)
$Font = New-Object System.Drawing.Font("Times New Roman", 12, [System.Drawing.FontStyle]::Regular)
$testcost.Font = $Font
$testcost.TransparencyKey = $backgroundImage.GetPixel(100, 500)
$testcost.BackColor = $backgroundImage.GetPixel(100, 400)
$testcost.text = "Begin Testing 4,8,64,512k"
$Form.Controls.Add($testcost)
 
$testcost.text = "Start Test Once you make your Selections, Results show here. Test is long! File is saved. "
 

 



$Form.Add_Shown({ $Form.Activate() })
[void] $Form.ShowDialog()

#endregion Main Form

